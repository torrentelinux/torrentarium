// Programa: WebSimple.java
// Autor   : Eugenio Martínez - Nov. de 2021
// Referencias: https://es.wikipedia.org/wiki/HTML
// __________________________________________________________________________

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Developer
 */
public class WebSimple extends HttpServlet
{
    int cuenta = 1;
    
    /**
     * Called by the server (via the service method) to allow a servlet to handle a GET request.
     * @param solicita
     * @param responde
     * @throws javax.servlet.ServletException
     * @throws IOException
     */
    @Override
    public void doGet(HttpServletRequest solicita, HttpServletResponse responde) throws ServletException, IOException 
    {
        HTML html = new HTML(responde);
        String titulo = "Cuenta...";

        // Aquí comienza el contenido html a publicar en el navegador de páginas HTML
        html.openHtml();

        html.openHead();
        html.setGenerator("Biblioteca de clase HTML, ver. 1.0, ed. Java");
        html.putTitle(titulo);
        html.closeHead();

        html.openBody();
        
        // Coloca el título muy grande y centrado en la pantalla.
        html.putTitle1(html.alignCenter(titulo));

        html.putTitle1("Presione F5 para actualizar contenido de la página.");
                
        html.putText("Cuenta tiene: " + cuenta);
        html.putText("Cada vez que se presiona la tecla F5, el contador se incrementa en una unidad.");
        html.closeBody();
        
        // Aquí termina el contenido html.
        html.closeHtml();
        
        // Se incrementa la variable en una unidad.
        cuenta++;
    }
}
