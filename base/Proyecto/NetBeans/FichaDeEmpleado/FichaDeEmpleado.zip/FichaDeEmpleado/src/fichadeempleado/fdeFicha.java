// fdeFicha.java
// Solicita el ingreso por teclado el apellido del empleado para efectuar una consulta al servidor SQL.
// Visualiza la ficha del empleado en una planilla de datos.
// Servidores SQL admitidos: MySQL y PostgreSQL.
// Versión 3.0 * Mayo de 2025.
// Desarrollado en Apache NetBeans IDE.
// Licencia: Software libre.
// -------------------------
package fichadeempleado;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Paths;
import java.sql.*;
import java.time.Duration;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Octulio Biletán
 * @version 3.0
 */
public class fdeFicha extends javax.swing.JFrame {

    private record sqlConexion(String jdbcControlador, String jdbcURL, String nombreusuario, String clave) {

    }

    private final sqlConexion mysql;
    private final sqlConexion postgres;
    private final sqlConexion todos;
    private final sqlConexion todosSQL[];

    private int servidor_seleccionado;  // el servidor SQL activo
    private int nservidores;            // cantidad total de servidores admitidos
    private String consulta;

    /**
     * ------------------------------------------------------------------------
     * Crea el nuevo formulario fdeFicha.
     * -------------------------------------------------------------------------
     */
    public fdeFicha() {
        initComponents();
        this.setTitle("Ficha de Empleado");

        txtApellido.setSelectionStart(0);
        txtApellido.setSelectionEnd(txtApellido.getText().length());
        consulta = "";

        // Indica todos los servidores SQL
        todos = null;

        // Cadena de conexión para PostgreSQL
        postgres = new sqlConexion("org.postgresql.Driver", "jdbc:postgresql://localhost:5432/persona", "postgres", (new StringBuffer("sergtsop").reverse()).toString());

        // Cadena de conexión para MySQL
        mysql = new sqlConexion("com.mysql.cj.jdbc.Driver", "jdbc:mysql://localhost:3306/persona", "sqlsys", (new StringBuffer("26syslqs").reverse()).toString());

        // Cadena de conexión genérica
        todosSQL = new sqlConexion[]{mysql, postgres, todos};

        // El servidor SQL por omisión, el 1ro. de la lista todosSQL[]
        servidor_seleccionado = 0;

        nservidores = 3;
        mensajeRegistroDeActividades("Directorio de la aplicación: " + dirAplic());
    }

    // Devuelve el directorio de la aplicación .jar
    private String dirAplic() {
        String dato;

        if (FileSystems.getDefault().getPath("").toAbsolutePath().toString().contains("\\dist")) {
            dato = Paths.get("").toAbsolutePath().toString();  // Estoy en \dist
        } else {
            dato = Paths.get("").toAbsolutePath().toString() + "\\dist";  // Agrego a \dist
        }

        return dato;
    }

    private int abrirNuevaPlanilla() {
        int codigoSalida = 0;
        String cmd;
        String miAplicacion;

        // El nombre de la aplicación a ejecutar
        miAplicacion = "\\FichaDeEmpleado.jar";

        // El nombre completo del comando a invocar
        cmd = dirAplic() + miAplicacion;

        try {
            // Invoca al intérprete de comandos del S.O. para ejecutar nuestra aplicación .jar
            Process Salida = new ProcessBuilder("cmd.exe", "/c", cmd).inheritIO().start();

            // Espera unos segundos...
            Thread.sleep(Duration.ofSeconds(2));

            if (Salida.isAlive()) {
                mensajeRegistroDeActividades("AVISO: La nueva planilla está abierta.");
            } else {
                mensajeRegistroDeActividades("ERROR: La planilla no está abierta.");
                codigoSalida = 1;
            }

        } catch (IOException | InterruptedException ex) {
            mensajeRegistroDeActividades(ex.getMessage());
            codigoSalida = -1;
        }

        return codigoSalida;
    }

    private void mensajeVisualizar(String msj) {
        JOptionPane.showMessageDialog(this, msj);
    }

    private void mensajeRegistroDeActividades(String msj) {
        txtRegistroActividades.append(msj);
        txtRegistroActividades.append("\n");
    }

    // Consulta el apellido del empleado en el servidor SQL elegido por el usuario
    private boolean consultarApellido(String ape) {
        int max_permitido = 15;
        String sqlConsulta;
        sqlConexion cnx = todos;

        if (Math.abs(servidor_seleccionado) < nservidores) {
            cnx = todosSQL[servidor_seleccionado];
        }

        mensajeRegistroDeActividades("Estableciendo conexión a base de datos 'Persona'...");

        // Define la consulta a efectuar en el servidor SQL
        if (ape.equals("*")) {
            sqlConsulta = "select * from empleado order by codigo";  // consulta toda la tabla empleado y la ordena por codigo
        } else {
            sqlConsulta = "select * from empleado where apellido = '" + ape + "'";  // 'ape' es el apellido a consultar
        }

        // Consulta en los diferentes servidores SQL registrados
        if (cnx == todos) {
            mensajeVisualizar("Advertencia: Opción no disponible.");
            return false;
        }

        try {
            // Registra el conector JDBC
            Class.forName(cnx.jdbcControlador);

        } catch (ClassNotFoundException | NullPointerException ex) {
            mensajeRegistroDeActividades("Error: No se pudo acceder a conector JDBC.\n" + ex.getMessage());
            return false;

        }

        // indice de fila en la tabla
        int f = 0;

        // limpia toda la tabla
        ((DefaultTableModel) tblEmpleado.getModel()).setRowCount(0);
        ((DefaultTableModel) tblEmpleado.getModel()).setRowCount(max_permitido);

        // Ordena la tabla por la 1ra. columna
        tblEmpleado.getRowSorter().toggleSortOrder(0);

        try {
            // Abre la conexion a la base de datos.
            Connection conexion = DriverManager.getConnection(cnx.jdbcURL, cnx.nombreusuario, cnx.clave);
            Statement sentencia = conexion.createStatement();
            ResultSet resultado = sentencia.executeQuery(sqlConsulta);

            int sqlColumna = 1;
            mensajeRegistroDeActividades("Consultando Apellido: " + ape);

            while (resultado.next()) {
                for (int c = 0; c < 4; c++) {
                    tblEmpleado.setValueAt(resultado.getString(sqlColumna++), f, c);
                }

                sqlColumna = 1;
                f++;
            }

            mensajeRegistroDeActividades("Encontrados: " + f);

            // Cierra la conexión a la base de datos.
            resultado.close();
            sentencia.close();
            conexion.close();

        } catch (SQLException ex) {

            mensajeRegistroDeActividades("Servidor: " + cnx.jdbcControlador + "\n" + ex.getMessage() + "\nCódigo SQL: " + ex.getSQLState());
            return false;

        } catch (ArrayIndexOutOfBoundsException ex) {
            mensajeRegistroDeActividades("¡¡Planilla llena!! (máximo = " + tblEmpleado.getModel().getRowCount() + " filas)");
        }

        return (f > 0);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlPrincipal = new javax.swing.JPanel();
        txtApellido = new javax.swing.JTextField();
        lblApellido = new javax.swing.JLabel();
        lblTitulo = new javax.swing.JLabel();
        btnConsultar = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblEmpleado = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtRegistroActividades = new javax.swing.JTextArea();
        btnTerminar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        btnLimpiar = new javax.swing.JButton();
        cmbServidor = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btnNuevaPlanilla = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Ficha");

        pnlPrincipal.setBackground(new java.awt.Color(102, 255, 102));

        txtApellido.setText("<ingrese apellido a consultar>");
        txtApellido.setToolTipText("<ingrese apellido a consultar>");
        txtApellido.setMinimumSize(new java.awt.Dimension(182, 30));
        txtApellido.setPreferredSize(new java.awt.Dimension(182, 30));
        txtApellido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtApellidoActionPerformed(evt);
            }
        });

        lblApellido.setText("Apellido:");

        lblTitulo.setFont(new java.awt.Font("Noto Sans", 0, 18)); // NOI18N
        lblTitulo.setText("Consulta de empleados");

        btnConsultar.setText("Consultar");
        btnConsultar.setToolTipText("Efectúa la consulta.");
        btnConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarActionPerformed(evt);
            }
        });

        tblEmpleado.setAutoCreateRowSorter(true);
        tblEmpleado.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Código", "Nombre", "Apellido", "Sueldo"
            }
        ));
        tblEmpleado.setToolTipText("Planilla de empleados.");
        tblEmpleado.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        tblEmpleado.setShowGrid(true);
        tblEmpleado.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblEmpleadoMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblEmpleado);

        txtRegistroActividades.setColumns(20);
        txtRegistroActividades.setRows(5);
        txtRegistroActividades.setToolTipText("Area de mensajes informativos.");
        jScrollPane2.setViewportView(txtRegistroActividades);

        btnTerminar.setText("Terminar");
        btnTerminar.setToolTipText("Termina la aplicación.");
        btnTerminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTerminarActionPerformed(evt);
            }
        });

        jLabel1.setText("Registro de Activdades");

        btnLimpiar.setText("Limpiar");
        btnLimpiar.setToolTipText("Limpia el registro de actividades.");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        cmbServidor.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "MySQL", "PostgreSQL", "Ambos servidores" }));
        cmbServidor.setToolTipText("Lista de servidores SQL.");
        cmbServidor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbServidorActionPerformed(evt);
            }
        });

        jLabel2.setText("Servidor:");

        jLabel3.setText("Planilla:");

        btnNuevaPlanilla.setText("Nueva Planilla");
        btnNuevaPlanilla.setToolTipText("Abre una nueva planilla.");
        btnNuevaPlanilla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevaPlanillaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlPrincipalLayout = new javax.swing.GroupLayout(pnlPrincipal);
        pnlPrincipal.setLayout(pnlPrincipalLayout);
        pnlPrincipalLayout.setHorizontalGroup(
            pnlPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlPrincipalLayout.createSequentialGroup()
                .addGroup(pnlPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlPrincipalLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(pnlPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlPrincipalLayout.createSequentialGroup()
                                .addGap(73, 73, 73)
                                .addComponent(jSeparator1)
                                .addGap(89, 89, 89))
                            .addGroup(pnlPrincipalLayout.createSequentialGroup()
                                .addComponent(btnLimpiar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnNuevaPlanilla)
                                .addGap(82, 82, 82)
                                .addComponent(btnTerminar))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addComponent(jScrollPane2)))
                    .addGroup(pnlPrincipalLayout.createSequentialGroup()
                        .addGap(121, 121, 121)
                        .addComponent(lblTitulo)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(pnlPrincipalLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(pnlPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlPrincipalLayout.createSequentialGroup()
                                .addGroup(pnlPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addGroup(pnlPrincipalLayout.createSequentialGroup()
                                        .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btnConsultar)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(pnlPrincipalLayout.createSequentialGroup()
                                .addComponent(lblApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGroup(pnlPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cmbServidor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))))
                .addContainerGap())
            .addGroup(pnlPrincipalLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlPrincipalLayout.setVerticalGroup(
            pnlPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlPrincipalLayout.createSequentialGroup()
                .addComponent(lblTitulo)
                .addGap(57, 57, 57)
                .addGroup(pnlPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblApellido)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnConsultar)
                    .addComponent(cmbServidor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 186, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnLimpiar)
                    .addComponent(btnTerminar)
                    .addComponent(btnNuevaPlanilla))
                .addGap(18, 18, 18))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnlPrincipal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnlPrincipal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtApellidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtApellidoActionPerformed
        consulta = txtApellido.getText();
        this.btnConsultarActionPerformed(evt);
    }//GEN-LAST:event_txtApellidoActionPerformed

    // Termina la aplicación, responde al evento 'Terminar'
    private void btnTerminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTerminarActionPerformed
        this.setVisible(false);
        this.dispose();
    }//GEN-LAST:event_btnTerminarActionPerformed

    private void btnConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarActionPerformed
        if (txtApellido.getText().length() > 0) {
            consulta = txtApellido.getText();
        } else {
            consulta = "";
        }

        mensajeRegistroDeActividades("Apellido a consultar: " + consulta);

        // Efectúa la consulta
        boolean estado = consultarApellido(consulta);
        if (estado == false) {
            mensajeRegistroDeActividades("No encontrado.");
        }
    }//GEN-LAST:event_btnConsultarActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        txtRegistroActividades.setText("");
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void cmbServidorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbServidorActionPerformed
        String dato_seleccionado = String.valueOf(cmbServidor.getSelectedItem());

        if (dato_seleccionado.equals("MySQL")) {
            servidor_seleccionado = 0;      // servidor mysql seleccionado
        } else if (dato_seleccionado.equals("PostgreSQL")) {
            servidor_seleccionado = 1;      // servidor postgresql seleccionado
        } else {
            servidor_seleccionado = 2;      // opción para todos los servidores SQL registrados por la aplicación
        }

        mensajeRegistroDeActividades("-Servidor SQL activo- " + servidor_seleccionado);
    }//GEN-LAST:event_cmbServidorActionPerformed

    private void tblEmpleadoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblEmpleadoMouseClicked
        // TODO add your handling code here:

    }//GEN-LAST:event_tblEmpleadoMouseClicked

    private void btnNuevaPlanillaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevaPlanillaActionPerformed
        // TODO add your handling code here:
        // Abre una nueva planilla
        abrirNuevaPlanilla();
    }//GEN-LAST:event_btnNuevaPlanillaActionPerformed

    /**
     * Entrada secundaria al programa.
     *
     * @param args Los argumentos que vienen de la línea de comandos.
     */
    public static void main(String args[]) {
        // Nombre del tema a establecer en la aplicación
        // Los temas pueden ser: Metal, Nimbus, CDE/Motif, GTK+, Windows, Windows Classic
        // Consultar en apartado 'Look and Feel', opción de menú 'Tools/Options'
        String temaIG = "Windows";
        boolean encontrado = false;

        // Inicializa la interfaz gráfica swing con el tema elegido en "temaIG"
        try {
            if (temaIG.equals("System")) {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                encontrado = true;
            } else {
                for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                    if (temaIG.equals(info.getName())) {
                        javax.swing.UIManager.setLookAndFeel(info.getClassName());
                        encontrado = true;
                        break;
                    }
                }
            }

            if (encontrado == false) {
                System.err.println("Advertencia: No se pudo establecer el tema '" + temaIG + "' en la aplicación.");
                System.err.println("Su entorno operativo acepta los siguientes temas:");

                for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                    System.err.println("* " + info.getName());
                }
            }

        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(fdeFicha.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            return;

        }

        // ____________________________________________________________
        // Ejecuta el formulario principal y lo presenta en la pantalla
        java.awt.EventQueue.invokeLater(() -> {
            new fdeFicha().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnConsultar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnNuevaPlanilla;
    private javax.swing.JButton btnTerminar;
    private javax.swing.JComboBox<String> cmbServidor;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblApellido;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JPanel pnlPrincipal;
    private javax.swing.JTable tblEmpleado;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextArea txtRegistroActividades;
    // End of variables declaration//GEN-END:variables
}
