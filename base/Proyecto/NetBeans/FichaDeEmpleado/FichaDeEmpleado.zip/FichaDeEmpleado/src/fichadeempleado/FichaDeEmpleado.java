// FichaDeEmpleado.java
// Versión 3.0 * Mayo de 2025.
// Desarrollado en Apache NetBeans IDE.
// Licencia: Software libre.
//
package fichadeempleado;

import java.awt.GraphicsEnvironment;

/**
 * Visualiza la ficha del empleado de la empresa.<br>
 * Fecha: Mayo de 2025
 *
 * @author Octulio Biletán
 * @version 3.0
 */
public class FichaDeEmpleado {

    /**
     * Entrada principal al programa.
     *
     * @param args Los argumentos que vienen de la línea de comandos.
     */
    public static void main(String[] args) {
        if (!GraphicsEnvironment.isHeadless()) {
            fdeFicha.main(args);  // Invoca la ventana principal de la aplicación
        } else {
            System.err.println("La interfaz gráfica del sistema debe estar activa para ejecutar la aplicación 'FichaDeEmpleado'.");
            System.exit(1);
        }
    }
}

/*
Desactivado
            System.out.println("pid=" + ProcessHandle.current().pid());
            System.out.println("current directory=" + Paths.get("").toAbsolutePath().toString());
            System.out.println("executable=" + ProcessHandle.current().info().command().get());

 */
