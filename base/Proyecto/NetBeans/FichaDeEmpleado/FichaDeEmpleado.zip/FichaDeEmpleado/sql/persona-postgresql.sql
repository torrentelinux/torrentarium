-- Adminer 5.3.0 PostgreSQL 17.2 dump
-- Base de datos 'persona' para PostgreSQL
-- Crear 1ro. la base de datos 'persona'
-- 21:33 viernes, 23 de mayo de 2025
--
-- Utilize el programa psql desde la línea de comandos para ejecutar este
-- programa en el servidor PostgreSQL.
-- Ejecutar "psql -U postgres" desde la consola de textos del S.O.
-- Se le pedirá que tipee la contraseña del superusuario "postgres".
-- Una vez ingresado a psql ya está listo para ejecutar órdenes de SQL.
-- Para pedir ayuda: help o también \? y presione tecla "Intro".
-- Para salir: \quit y presione tecla "Intro".
-- Para conocer cuáles son las bases de datos alojadas en el servidor:
-- select * from pg_database;
-- Para ejecutar este programa:
-- \i persona-postgresql.sql
-- Para borrar la pantalla:
-- \! cls    * Windows
-- \! clear  * Linux

SET default_transaction_read_only = off;
SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET search_path = public, pg_catalog;
SET default_tablespace = '';
SET default_with_oids = false;

-- Definición de la base de datos Persona.
CREATE DATABASE if not exists "persona" WITH TEMPLATE = template0 ENCODING = 'UTF8' TABLESPACE = pg_default;
COMMENT ON DATABASE "persona" IS 'Sistema de sueldos al personal de la empresa.';

\connect "persona";
\conninfo

DROP TABLE IF EXISTS "empleado";
CREATE TABLE "public"."empleado" (
    "codigo" integer NOT NULL,
    "nombre" character varying(16) NOT NULL,
    "apellido" character varying(16) NOT NULL,
    "sueldo" character varying(16),
    CONSTRAINT "empleado_codigo" PRIMARY KEY ("codigo")
)
WITH (oids = false);

CREATE UNIQUE INDEX empleado_unico_codigo ON public.empleado USING btree (codigo);
CREATE INDEX empleado_indice_codigo ON public.empleado USING btree (codigo);

TRUNCATE "empleado";
INSERT INTO "empleado" ("codigo", "nombre", "apellido", "sueldo") VALUES
(200,	'carlos',	'medina',	'1.100.400'),
(100,	'lia',		'rosales',	'1.200.123'),
(99,	'liliana',	'rodriguez',	'951.000'),
(350,	'isabel',	'medina',	'2.090.056,23'),
(351,	'isabel',	'mendez',	'2.070.056,23'),
(353,	'ismael',	'ruiz',		'2.099.056,23'),
(352,	'ismael',	'rosales',	'2.090.156,23'),
(354,	'mabel',	'mirinda',	'1.090.066,23'),
(357,	'daniela',	'miranda',	'1.990.056,25'),
(199,	'sabrina',	'medina',	'<sin sueldo>');
