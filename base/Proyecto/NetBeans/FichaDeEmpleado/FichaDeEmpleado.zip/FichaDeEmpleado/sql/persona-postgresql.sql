-- Adminer 5.3.0 PostgreSQL 17.2 dump
-- Base de datos 'persona' para PostgreSQL
-- Crear 1ro. la base de datos 'persona'
-- 23:59 lunes, 19 de mayo de 2025

\connect "persona";

DROP TABLE IF EXISTS "empleado";
CREATE TABLE "public"."empleado" (
    "codigo" integer NOT NULL,
    "nombre" character varying(16) NOT NULL,
    "apellido" character varying(16) NOT NULL,
    "sueldo" character varying(16),
    CONSTRAINT "empleado_codigo" PRIMARY KEY ("codigo")
)
WITH (oids = false);

CREATE UNIQUE INDEX empleado_unico_codigo ON public.empleado USING btree (codigo);
CREATE INDEX empleado_indice_codigo ON public.empleado USING btree (codigo);

TRUNCATE "empleado";
INSERT INTO "empleado" ("codigo", "nombre", "apellido", "sueldo") VALUES
(200,	'carlos',	'medina',	'1.100.400'),
(100,	'lia',		'rosales',	'1.200.123'),
(99,	'liliana',	'rodriguez',	'951.000'),
(350,	'isabel',	'medina',	'2.090.056,23'),
(199,	'sabrina',	'medina',	'<sin sueldo>');
