-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 21:33 viernes, 23 de mayo de 2025
-- Versión del servidor: 8.4.3
-- Versión de PHP: 8.3.16
-- Base de datos 'persona' para MySQL

-- Ingresar al servidor con el comando 'mysql -u root -p' desde la línea de comandos.
-- Ejecute el comando "source persona-mysql.sql" para crear la base de datos "persona" y cargar sus datos.
-- Ejecute comando "show databases;" para visualizar las bases de datos existentes.
-- Puede solicitar una ayuda ==> \h

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `persona`
--
CREATE DATABASE if not exists persona;
USE persona;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado`
--

DROP TABLE IF EXISTS `empleado`;
CREATE TABLE `empleado` (
  `codigo` int NOT NULL,
  `nombre` varchar(16) NOT NULL,
  `apellido` varchar(16) NOT NULL,
  `sueldo` varchar(16) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `empleado`
--

INSERT INTO `empleado` (`codigo`, `nombre`, `apellido`, `sueldo`) VALUES
(99, 'asdfg', 'lkjhg', '300100'),
(100, 'juan', 'perez', '498897'),
(101, 'romina', 'ponce', '500428'),
(102, 'roberto', 'juarez', '654258'),
(103, 'benjamin', 'rodriguez', '789321'),
(300, 'isabel', 'medina', '1.200.000,25'),
(399, 'rosalia del car.', 'medina', '789.654,23'),
(400, 'romina', 'mendizabal', '1.590.339,720999'),
(401, 'gabriel', 'mendilaharzu', '998.345,2498'),
(404, 'gabriela', 'mendez', '991.945,24'),
(501, 'esteban', 'medina', '1.321.951,758990');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `empleado`
--
ALTER TABLE `empleado`
  ADD PRIMARY KEY (`codigo`),
  ADD UNIQUE KEY `codigo_2` (`codigo`),
  ADD KEY `codigo` (`codigo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
