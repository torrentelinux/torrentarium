/*
 * Copyright (c) 1997, 2011, Oracle and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *   - Neither the name of Oracle nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

 /*
 * This source code is provided to illustrate the usage of a given feature
 * or technique and has been deliberately simplified. Additional steps
 * required for a production-quality application, such as security checks,
 * input validation and proper error handling, might not be present in
 * this sample code.
 */
//
// --------------------------------------------------
// Código fuente modificado por Octulio Biletán.
// Fecha: 30/5/2026
// Adaptado para el proyecto 'ConsultaDeEstudiantes'.
// Versión: 1.5.2026
// Referencias: https://github.com/openjdk/jdk/blob/master/src/demo/share/jfc/TableExample/JDBCAdapter.java
// --------------------------------------------------
//
package consultaestudiantes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 * An adaptor, transforming the JDBC interface to the TableModel interface.
 *
 * @author Philip Milne
 */
@SuppressWarnings("serial")
public class JDBCAdapter extends AbstractTableModel
{
    Connection connection;
    Statement statement;
    ResultSet resultSet;
    String[] columnNames = {};
    List<List<Object>> rows = new ArrayList<List<Object>>();
    ResultSetMetaData metaData;

    /// Establece una conexión al servidor de base de datos SQL mediante un conector JDBC suministrado por el usuario.<br>
    /// El controlador JDBC es un archivo de tipo .jar<br>
    /// <strong>Ejemplo:</strong><br>
    /// <pre>    JDBCAdapter conexion = new JDBCAdapter("jdbc:mysql://localhost:3306/basedatos", "com.mysql.cj.jdbc.Driver", "operador", "clave");</pre>
    /// @param url Se compone de la siguiente forma:<br>
    /// <pre>      jdbc:'servidor_sql'://'dirección':'puerto'/'nombre_base_datos'</pre>
    /// @param driverName El nombre del controlador JDBC.
    /// @param user Nombre de la cuenta de usuario.
    /// @param passwd La clave de acceso.
    public JDBCAdapter(String url, String driverName, String user, String passwd)
    {
        try {
            Class.forName(driverName);
            System.out.println("Opening db connection");

            connection = DriverManager.getConnection(url, user, passwd);
            statement = connection.createStatement();

        } catch (ClassNotFoundException ex) {
            System.err.println("Cannot find the database driver classes.");
            System.err.println(ex);
        } catch (SQLException ex) {
            System.err.println("Cannot connect to this database.");
            System.err.println(ex);
        }
    }

    /// Execute query.
    /// @param query
    public void executeQuery(String query)
    {
        if (connection == null || statement == null) {
            System.err.println("There is no database to execute the query.");
            return;
        }
        try {
            resultSet = statement.executeQuery(query);
            metaData = resultSet.getMetaData();

            int numberOfColumns = metaData.getColumnCount();
            columnNames = new String[numberOfColumns];
            // Get the column names and cache them.
            // Then we can close the connection.
            for (int column = 0; column < numberOfColumns; column++) {
                columnNames[column] = metaData.getColumnLabel(column + 1);
            }

            // Get all rows.
            rows = new ArrayList<List<Object>>();
            while (resultSet.next()) {
                List<Object> newRow = new ArrayList<Object>();
                for (int i = 1; i <= getColumnCount(); i++) {
                    newRow.add(resultSet.getObject(i));
                }
                rows.add(newRow);
            }
            //  close(); Need to copy the metaData, bug in jdbc:odbc driver.

            // Tell the listeners a new table has arrived.
            fireTableChanged(null);
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
            System.err.println("Cláusula: " + query);
        }
    }

    /// Close database connection.
    /// @throws SQLException
    public void close() throws SQLException
    {
        System.out.println("Closing db connection");
        resultSet.close();
        statement.close();
        connection.close();
    }

    //************************************************************************
    //
    //             Implementation of the TableModel Interface
    //
    //************************************************************************

    ///
    /// @param column
    /// @return
    @Override
    public String getColumnName(int column)
    {
        if (columnNames[column] != null) {
            return columnNames[column];
        } else {
            return "";
        }
    }

    ///
    /// @param column
    /// @return
    @Override
    public Class<?> getColumnClass(int column)
    {
        int type;
        try {
            type = metaData.getColumnType(column + 1);
        } catch (SQLException e) {
            return super.getColumnClass(column);
        }

        switch (type) {
            case Types.CHAR:
            case Types.VARCHAR:
            case Types.LONGVARCHAR:
                return String.class;

            case Types.BIT:
                return Boolean.class;

            case Types.TINYINT:
            case Types.SMALLINT:
            case Types.INTEGER:
                return Integer.class;

            case Types.BIGINT:
                return Long.class;

            case Types.FLOAT:
            case Types.DOUBLE:
                return Double.class;

            case Types.DATE:
                return java.sql.Date.class;

            default:
                return Object.class;
        }
    }

    ///
    /// @param row
    /// @param column
    /// @return
    @Override
    public boolean isCellEditable(int row, int column)
    {
        try {
            return metaData.isWritable(column + 1);
        } catch (SQLException e) {
            return false;
        }
    }

    ///
    /// @return
    @Override
    public int getColumnCount()
    {
        return columnNames.length;
    }

    // Data methods

    ///
    /// @return
    @Override
    public int getRowCount()
    {
        return rows.size();
    }

    ///
    /// @param aRow
    /// @param aColumn
    /// @return
    @Override
    public Object getValueAt(int aRow, int aColumn)
    {
        List<Object> row = rows.get(aRow);
        return row.get(aColumn);
    }

    ///
    /// @param column
    /// @param value
    /// @return
    public String dbRepresentation(int column, Object value)
    {
        int type;

        if (value == null) {
            return "null";
        }

        try {
            type = metaData.getColumnType(column + 1);
        } catch (SQLException e) {
            return value.toString();
        }

        switch (type) {
            case Types.INTEGER:
            case Types.DOUBLE:
            case Types.FLOAT:
                return value.toString();
            case Types.BIT:
                return ((Boolean) value).booleanValue() ? "1" : "0";
            case Types.DATE:
                return value.toString(); // This will need some conversion.
            default:
                return "\"" + value.toString() + "\"";
        }
    }

    ///
    /// @param value
    /// @param row
    /// @param column
    @Override
    public void setValueAt(Object value, int row, int column)
    {
        int modificado;
        String tmp;
        char caracter[];

        try {
            String tableName = metaData.getTableName(column + 1);
            // Some of the drivers seem buggy, tableName should not be null.
            if (tableName == null) {
                System.out.println("Table name returned null.");
            }
            String columnName = getColumnName(column);
            String query
                    = "update " + "`" + tableName + "`" + " set " + "`" + columnName + "`" + " = "
                    + dbRepresentation(column, value) + " where ";
            // We don't have a model of the schema so we don't know the
            // primary keys or which columns to lock on. To demonstrate
            // that editing is possible, we'll just lock on everything.
            for (int col = 0; col < getColumnCount(); col++) {
                String colName = getColumnName(col);
                if (colName.equals("")) {
                    continue;
                }
                if (col != 0) {
                    query = query + " and ";
                }

                // --Modificado-por-Octulio-Biletán-----------------------------
                tmp = dbRepresentation(col, getValueAt(row, col));
                caracter = tmp.toCharArray();
                int guion = 0;

                for (int i = 0; i < caracter.length; i++) {
                    if (caracter[i] == '-') {
                        guion++;
                    }
                }

                // ¿Se trata de un campo fecha?
                if (guion == 2) {
                    // Encierra entre comillas a dicho campo
                    query = query + "`" + colName + "`" + " = " + "\"" + tmp + "\"";
                } else {
                    query = query + "`" + colName + "`" + " = " + dbRepresentation(col, getValueAt(row, col));
                }
                // --Final-líneas-----------------------------------------------

                // Deshabilitado: línea original
                // query = query + "`" + colName + "`" + " = " + dbRepresentation(col, getValueAt(row, col));
            }

            System.out.println(query);

            // Líneas originales deshabilitadas
            // System.out.println("Not sending update to database");
            // statement.executeQuery(query);

            modificado = statement.executeUpdate(query);
            System.out.println("Datos actualizados=" + modificado);

        } catch (SQLException e) {
            // e.printStackTrace();
            modificado = 0;
            System.err.println("Datos actualizados=" + modificado);
        }

        List<Object> dataRow = rows.get(row);
        dataRow.set(column, value);
    }

    /// Devuelve el nº de versión correspondiente a esta clase.<br>
    /// <strong>Formato</strong>: "x.y.z"<br>
    /// <strong>Ejemplo</strong>: "1.5.2026"<br>
    /// @return El nº de versión.
    public String getVersion()
    {
        return "1.5.2026";
    }
}
