-- --------------------------------------------------------
-- Host:			127.0.0.1
-- Versión del servidor:	8.4.3 - MySQL Community Server - GPL
-- SO del servidor:		Win64
-- HeidiSQL Versión:		12.8.0.6908
-- Base de datos:		centroeducativo.
-- Tablas:			inscriptos.
-- Autor:			Octulio Biletán.
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para centroeducativo
DROP DATABASE IF EXISTS `centroeducativo`;
CREATE DATABASE IF NOT EXISTS `centroeducativo` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `centroeducativo`;

-- Volcando estructura para tabla centroeducativo.inscriptos
DROP TABLE IF EXISTS `inscriptos`;
CREATE TABLE IF NOT EXISTS `inscriptos` (
  `matricula` int unsigned NOT NULL COMMENT 'Nº de matrícula',
  `nombre` varchar(30) NOT NULL COMMENT 'Nombres del estudiante.',
  `apellido` varchar(30) NOT NULL COMMENT 'Apellidos del estudiante.',
  `fechainscripto` date NOT NULL COMMENT 'Fecha de inscripción del estudiante.',
  `metodopago` enum('Contado','TCredito','TDebito','CBU','Otro') NOT NULL COMMENT 'Método de pago del estudiante.',
  `montopago` decimal(16,2) NOT NULL COMMENT 'Monto del pago del estudiante.',
  `carrera` varchar(50) NOT NULL COMMENT 'Nombre de la carrera que cursa el estudiante.',
  `curso` int NOT NULL COMMENT 'Nº de curso del estudiante.',
  PRIMARY KEY (`matricula`),
  UNIQUE KEY `matricula` (`matricula`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Registro de estudiantes inscriptos al Centro Educativo.\r\nProfesor Eugenio Martínez.\r\nMayo de 2026.\r\n';

-- Volcando datos para la tabla centroeducativo.inscriptos: ~8 rows (aproximadamente)
DELETE FROM `inscriptos`;
INSERT INTO `inscriptos` (`matricula`, `nombre`, `apellido`, `fechainscripto`, `metodopago`, `montopago`, `carrera`, `curso`) VALUES
	(103134, 'omar', 'nacusse', '2026-05-28', 'Contado', 850000.00, 'licenciatura', 1),
	(103140, 'fabiana', 'alcorta', '2026-05-29', 'CBU', 850000.00, 'licenciatura', 1),
	(103141, 'raul', 'sosa', '2026-05-29', 'Contado', 750000.00, 'tecnicatura', 1),
	(103142, 'alicia', 'monteros', '2026-05-29', 'TCredito', 750000.00, 'tecnicatura', 1),
	(103147, 'juan', 'díaz', '2026-05-29', 'Contado', 850000.00, 'tecnicatura', 2),
	(103148, 'rafael miguel', 'balcarce', '2026-05-29', 'Contado', 790000.00, 'profesorado', 1),
	(103149, 'antonella', 'lópez', '2026-05-29', 'CBU', 790000.00, 'profesorado', 1),
	(103150, 'maría josé', 'pérez', '2026-05-29', 'CBU', 850000.00, 'tecnicatura', 2),
	(103151, 'rafael josé', 'brizuela', '2026-05-29', 'Contado', 790000.00, 'profesorado', 1),
	(103153, 'antonia', 'nacusse', '2026-05-29', 'CBU', 790000.00, 'profesorado', 1);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
