<%-- 
    Document   : index.jsp
    URL        : http://localhost:8080/SlideShowApp/
    Author     : Octulio Biletán
    Created on : Aug 13, 2026, 2:48:55 PM
    Tools      : Zulu Java JDK 25, Eclipse GlassFish Server 8.0, Apache NetBeans IDE 30
    O.S.       : Windows Server 2019 Standard
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" info="hoja principal" %>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Proyector de imágenes</title>
    <style>
        body { text-align: center; background: #111; color: white; font-family: Arial, sans-serif; }
        img { max-width: 80%; height: auto; border: 5px solid white; transition: opacity 0.5s ease-in-out; }
        .fade-out { opacity: 0; }
        .fade-in { opacity: 1; }
        .info { margin-top: 15px; font-size: 14px; color: #ccc; }
        .contador {
            position: fixed;
            bottom: 15px;
            right: 20px;
            background: rgba(0,0,0,0.6);
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 14px;
            color: #fff;
        }
    </style>
</head>
<body>
    <h1>Presentación de Imágenes</h1>
    <img id="slide" src="" alt="Diapositiva">
    <div class="info">
        [Espacio] Pausar/Reanudar — [T] Terminar — [←] Anterior — [→] Siguiente
    </div>
    <div id="contador" class="contador">0 / 0</div>

<!-- Código en Javascript -->
    <script>
        let imagenes = [];
        let index = 0;
        let intervalo = null;
        let pausado = false;
        const slide = document.getElementById("slide");
        const contador = document.getElementById("contador");

    function actualizarContador(i) {
            contador.textContent = (i+1) + " / " + imagenes.length;
        }

        function mostrarImagen(i) {
            slide.classList.remove("fade-in");
            slide.classList.add("fade-out");
            setTimeout(() => {
                slide.src = 'imagenes/' + imagenes[i];
                slide.classList.remove("fade-out");
                slide.classList.add("fade-in");
                actualizarContador(i);
            }, 300);
        }

        function iniciarPresentacion() {
            clearInterval(intervalo);
            if (imagenes.length > 0) {
                mostrarImagen(index);
                intervalo = setInterval(() => {
                    index = (index + 1) % imagenes.length;
                    mostrarImagen(index);
                }, 3000);
            }
        }

        function pausarReanudar() {
            if (pausado) {
                iniciarPresentacion();
                pausado = false;
            } else {
                clearInterval(intervalo);
                pausado = true;
            }
        }

        function terminarPresentacion() {
            clearInterval(intervalo);
            index = 0;
            mostrarImagen(index);
            pausado = true;
        }

        function siguienteImagen() {
            if (imagenes.length > 0) {
                index = (index + 1) % imagenes.length;
                mostrarImagen(index);
            }
        }

        function anteriorImagen() {
            if (imagenes.length > 0) {
                index = (index - 1 + imagenes.length) % imagenes.length;
                mostrarImagen(index);
            }
        }

        // Cargar imágenes desde el servlet
        fetch('lista-imagenes')
            .then(res => res.json())
            .then(data => {
                imagenes = data;
                if (imagenes.length > 0) {
                    index = 0;
                    actualizarContador(index);
                    iniciarPresentacion();
                } else {
                    contador.textContent = "0 / 0";
                }
            });

        // Controles de teclado
        document.addEventListener("keydown", (e) => {
            if (e.code === "Space") {
                e.preventDefault();
                pausarReanudar();
            } else if (e.key.toLowerCase() === "t") {
                terminarPresentacion();
            } else if (e.code === "ArrowRight" && pausado) {
                siguienteImagen();
            } else if (e.code === "ArrowLeft" && pausado) {
                anteriorImagen();
            }
        });
    </script>
<!-- Código en Java -->
<% 
    String msg;
    msg = "Desarrollado por <a href=\"https://x.com/euxeniumartinez\" target=\"_blank\">Octulio Biletán</a> * <a href=\"http://localhost/guiapractica.php\" target=\"_blank\">Guía práctica</a> * Agosto 2026";
    
    // Traza una línea horizontal
    out.println("<br><hr width=\"100%\" size=\"2\">");
    
    out.print("<p>" + msg + "</p>");
%>
</body>
</html>
