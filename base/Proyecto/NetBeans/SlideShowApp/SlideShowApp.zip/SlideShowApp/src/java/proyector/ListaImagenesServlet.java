/*
    Proyecto   : SlideShowApp
    Paquete    : proyector
    Módulo     : ListaImagenesServlet.java
    Autor      : Octulio Biletán - Agosto de 2026
    Librería   : Se utilizó 'Eclipse GlassFish Server' versión 8.0
    Descripción: Proyector de imágenes, lee todos los nombres de los archivos tipo gráficos
                 que están en el directorio /imagenes que luego serán visualizados en el cliente web.
*/
package proyector;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Permite visualizar en el navegador web imágenes gráficas con formato jpg, png y webp.<br>
 * @author Octulio Biletán
 */
@WebServlet("/lista-imagenes")
public class ListaImagenesServlet extends HttpServlet
{
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        String ruta = getServletContext().getRealPath("/imagenes");
        File carpeta = new File(ruta);

        List<String> imagenes = Arrays.stream(carpeta.listFiles())
                .filter(f -> f.isFile() && f.getName().matches(".*\\.(jpg|png|webp)$"))
                .map(File::getName)
                .collect(Collectors.toList());

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        String json = "[" + imagenes.stream()
                .map(img -> "\"" + img + "\"")
                .collect(Collectors.joining(",")) + "]";
        response.getWriter().write(json);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo()
    {
        return "Proyector de imágenes.";
    }// </editor-fold>
}
