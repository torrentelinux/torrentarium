<?php
/**
 * Guía Práctica de "Presentación de Imágenes"
 * Aplicación SlideShowApp alojada en el servidor local de Glassfish.
 * Este archivo 'guiapractica.php' tiene que estar alojado en el directorio
 * c:\laragon\www\
 */

$templateLines = [];
for ($i = 1; $i <= 15; $i++)
{
    $placeholder = "{{LINE{$i}}}";
    $templateLines[] = str_pad($placeholder, 132, ' ');
}

$template = implode("\n", $templateLines);

$replacements = [
    '{{LINE1}}'  => 'Guía práctica de "Presentación de Imágenes"<br><br>',
    '{{LINE2}}'  => '<u>Uso de las teclas:</u><br>',
    '{{LINE3}}'  => '[espacio] Permite pausar o reanudar la presentación de las imágenes.<br>',
    '{{LINE4}}'  => '[t] Termina la presentación de imágenes.<br>',
    '{{LINE5}}'  => '[flecha izquierda] Se desplaza hacia la imágen anterior.<br>',
    '{{LINE6}}'  => '[flecha derecha] Se desplaza hacia la imágen siguiente.<br>',
    '{{LINE7}}'  => 'Puede cerrar la ventana de visualización presionando [X] sobre la pestaña superior.<br><br>',
    '{{LINE8}}'  => '<u>Las imágenes:</u><br>',
    '{{LINE9}}'  => 'Todas las imágenes tienen que estar alojadas en el directorio \'web/imagenes/\' de la aplicación SlideShowApp.<br>',
    '{{LINE10}}' => 'Los formatos de imágenes admitidos son: .jpg, .png y .webp<br>',
    '{{LINE11}}' => 'Para que la aplicación funcione correctamente tiene que haber por lo menos una imágen gráfica en el directorio antes mencionado.',
    '{{LINE12}}' => '<br>_________________________________________________________________________________________________________________________________',
    '{{LINE13}}' => '<br>Esta aplicación ha sido desarrollada en Apache NetBeans IDE versión 30.',
    '{{LINE14}}' => '<br>El servidor de aplicaciones que se utilizó fué Eclipse Glassfish versión 8.0.0',
    '{{LINE15}}' => '<br>Github: <a href="https://github.com/torrentelinux/torrentarium/tree/master/base/Proyecto/NetBeans/SlideShowApp">SlideShowApp</a>'
];

foreach ($replacements as $placeholder => $value) 
{
    $safeValue = substr(str_pad($value, 132, ' '), 0, 132);
    $template = str_replace($placeholder, $safeValue, $template);
}

header('Content-Type: text/html; charset=UTF-8');
echo('<html lang="es"><head>'); echo "\n";
echo('<title>Presentación de imágenes</title>'); echo "\n";
echo('</head>'); echo "\n";
echo('<body>'); echo "\n";
echo('<p>'); echo "\n";

print($template);

echo('<br></p>'); echo "\n";
echo('</body>'); echo "\n";
echo('</html>'); echo "\n";
