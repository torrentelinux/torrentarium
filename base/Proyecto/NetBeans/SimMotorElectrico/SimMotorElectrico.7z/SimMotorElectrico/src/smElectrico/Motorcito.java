// Proyecto: SimMotorElectrico
// Programa: Motorcito.java
// Edmund Muslok * Octubre de 2024.
// Simulaci�n de un motor el�ctrico.
// Ejemplo de ciclo 'do...while'.
// Referencias:
//	https://www.baeldung.com/java-delay-code-execution
//

package smElectrico;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Simulaci�n de un motor el�ctrico.
 * @author Edmund Muslok
 */
public class Motorcito
{
// ----�Bloque de definici�n de las variables�----
        static boolean cycle;
        static boolean dato1;

        static int cuenta = 0;

        static String accion = "encendido.";
        static String dato2;

// ----�Bloque de definici�n de los m�todos�------
    private static void print(String texto)
    {
        System.out.println(texto);
    }

    private static boolean repeat()
    {
        cycle  = dato1;     // true=activo; false=inactivo
        accion = dato2;     // lavando;     apagado

        return cycle;
    }

    private static void delay(int lapsoTiempo) throws InterruptedException
    {
        TimeUnit.SECONDS.sleep(lapsoTiempo);  // demora de 'lapsoTiempo' segundos.
    }

    private static Runnable localTask()
    {
        return new localTask1();
    }

    private static class localTask1 implements Runnable
    {
        @Override
        public void run()
        {
          print("trabajando..." + Integer.toString(cuenta++));
          if(cuenta == 7)	// Cuando 'cuenta' llegue a 7 proceda a apagar el motorcito
          {
            dato1 = false;
            dato2 = "apagado.";
            cuenta = 0;
          }
        }
    }

// -----------------------------------------------------------
    /**
     * @param args the command line arguments
     * @throws java.lang.InterruptedException
     */
    public static void main(String[] args) throws InterruptedException
    {
        ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();
        executorService.scheduleAtFixedRate(Motorcito.localTask(), 0, 5, TimeUnit.SECONDS);

        print("< Simulaci�n de un motor el�ctrico >");
        dato1 = true;
        dato2 = "lavando.";

        do
        {

            print(accion);
            delay(1);

        } while(repeat());

        print(accion);
        executorService.shutdown();
        print("Simulaci�n concluida.");
    }
// -----------------------------------------------------------
}
