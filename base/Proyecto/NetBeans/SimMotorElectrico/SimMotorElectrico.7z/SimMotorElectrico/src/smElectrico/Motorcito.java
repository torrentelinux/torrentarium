// Proyecto: SimMotorElectrico
// Programa: Motorcito.java
// Edmund Muslok * Octubre de 2024.
// Simulaci�n de un motor el�ctrico.
// Ejemplo de ciclo 'do...while'.
// Programaci�n concurrente.
// Referencias:
//	https://www.baeldung.com/java-delay-code-execution
//

package smElectrico;

import java.awt.Toolkit;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import javax.swing.JOptionPane;

/**
 * Simulaci�n de un motor el�ctrico.
 * @author Edmund Muslok
 */
public class Motorcito
{
// ----�Bloque de definici�n de las variables�----
        static boolean cycle;
        static boolean potencia;

        static int cuenta = 0;

        static String accion = "encendido";     // la acci�n es el comando que se est� llevando a cabo ahora mismo
        static String comando;                  // comandos v�lidos: encendido, lavando, pausa, centrifugando, apagado
        static String version = "2.10.2024";

// ----�Bloque de definici�n de los m�todos�------
/**
 * clearSCR() borra toda la pantalla mediante c�digos de control de la consola nativa del S.O.<br>
 * Consultar p�gina de manual: man 4 console_codes.<br>
 */
    private static void clearSCR()
    {
        System.out.print("\033[2J\033[H");
        System.out.flush();
    }

    /**
     * print() Visualiza 'texto' en pantalla y realiza un avance autom�tico de l�nea.
     * @param texto El texto a mostrar en pantalla.<br>
     */
    private static void print(String texto)
    {
        System.out.println(texto);
    }

    private static boolean repeat()
    {
        cycle  = potencia;  // true=activo; false=inactivo
        accion = comando;   // lavando;     apagado

        return cycle;
    }

    private static void delay(int lapsoTiempo) throws InterruptedException
    {
        TimeUnit.SECONDS.sleep(lapsoTiempo);  // demora de 'lapsoTiempo' segundos.
    }

    /**
     * beep() emite un sonido simple por el parlante del dispositivo en uso.<br>
     * El tipo de sonido es dependiente del S.O. y del dispositivo que se est� utilizando.
     */
    private static void beep()
    {
        Toolkit.getDefaultToolkit().beep();
    }
    
    private static void displayMessageDialog(String titulo, String mensaje)
    {
        JOptionPane.showMessageDialog(null, mensaje, titulo, JOptionPane.INFORMATION_MESSAGE);
    }
    
    private static Runnable localTask()
    {
        return new microMotor();
    }

    /**
       Clase microMotor que define el m�todo run()
    */
    private static class microMotor implements Runnable
    {
        @Override
        public void run()
        {
          print("trabajando..." + Integer.toString(cuenta));

          if(cuenta == 9)	// Cuando 'cuenta' llegue a 9 proceda a apagar el motorcito
          {
            potencia = false;
            comando = "apagado";
            cuenta = 0;
          }

          if(cuenta == 3)       // Cuando 'cuenta' llegue a 3 procede a hacer una pausa
          {
              potencia = true;
              comando = "pausa";
          }

          if(cuenta == 4)
          {
              potencia = true;     // Cuando 'cuenta' llegue a 4 procede a reanudar su tarea
              comando = "lavando";
          }

          if(cuenta == 8)
          {
              potencia = true;     // Cuando 'cuenta' llegue a 8 procede a centrifugar
              comando = "centrifugando";
          }

          cuenta++;     // incrementa el contador en una unidad
        }
    }

// -----------------------------------------------------------
    /**
     * Entrada principal a la aplicaci�n SimMotorElectrico.
     * @param args the command line arguments
     * @throws java.lang.InterruptedException
     */
    public static void main(String[] args) throws InterruptedException
    {
        displayMessageDialog("SimMotorElectrico", "Simulaci�n de un motor el�ctrico.");
        long t1 = System.currentTimeMillis();
        beep();
        
        ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();
        executorService.scheduleAtFixedRate(Motorcito.localTask(), 1, 5, TimeUnit.SECONDS);

        clearSCR();
        print("SimMotorElectrico, versi�n " + version);
        print("Simulaci�n de un motor el�ctrico.");

        potencia = true;
        comando = "lavando";

        do
        {

            print(accion);
            delay(1);

        } while(repeat());

        print(accion);
        executorService.shutdown();
        beep();
        print("Simulaci�n concluida.");
        
        long t2 = System.currentTimeMillis();
        displayMessageDialog("Aviso", String.format("Tiempo consumido (segs.): %.3f", (t2-t1)/1000.0));
    }
// -----------------------------------------------------------
}
