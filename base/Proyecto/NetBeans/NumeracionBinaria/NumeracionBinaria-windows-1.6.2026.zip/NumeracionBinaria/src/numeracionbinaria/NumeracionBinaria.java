// Proyecto: NumeracionBinaria
// Programa: NumeracionBinaria.java
// Autor: Octulio Biletán - Junio de 2026
// Objetivos: Proporcionar un software educativo para la enseñanza del sistema de numeración binaria.
// Notas: El proyecto ha sido construído en NetBeans IDE.
// Compilar .java: javac src\numeracionbinaria\NumeracionBinaria.java
// Ejecutar .class: java -cp src numeracionbinaria.NumeracionBinaria
// Ejecutar .jar: java -jar dist\NumeracionBinaria.jar
// Referencias:
//      https://es.wikipedia.org/wiki/Código_binario
// Licencia: Software Libre.

package numeracionbinaria;

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 * @author Octulio Biletán
 * Fecha: 4/6/2026.
 */
public class NumeracionBinaria
{
    private boolean salir;
    private char opcion;
    private int so_codigo;  // 1=windows; 2=linux; -1=desconocido

    public NumeracionBinaria()
    {
        opcion = 0;
        salir = false;

        String so_nombre = System.getProperty("os.name").toLowerCase();

        if(so_nombre.contains("windows"))
        {
            so_codigo = 1;
        }
        else
        {
            if(so_nombre.contains("linux"))
                so_codigo = 2;
            else
                so_codigo = -1;
        }
        //System.out.println(so_codigo);
    }

    public void ejecutar()
    {
        beep();
        cls();

        System.out.println("Sistema de numeración binaria\n");
        MenuPrincipal();

        while (!salir) {
            try {
                opcion = (char) System.in.read();
            } catch (IOException ex) {
                System.getLogger(NumeracionBinaria.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
            }

            switch (opcion) {
                case '\r':
                case '\n':
                        break;

                case '1':    // opcion 1
                        TablaConversion();
                        cls();
                        MenuPrincipal();
                        break;

                case '2':   // opcion 2
                        Decimal_Binario();
                        cls();
                        MenuPrincipal();
                        break;

                case '3':   // opcion 3
                        Binario_Decimal();
                        cls();
                        MenuPrincipal();
                        break;

                case '4':   // opcion 4
                        operarCalculos();
                        cls();
                        MenuPrincipal();
                        break;

                case '5':   // opcion 5
                        abrirCalculadora();
                        cls();
                        MenuPrincipal();
                        break;

                case '6':   // opcion 6
                        abrirNavegador("https://www.areatecnologia.com/sistema-binario.htm");
                        cls();
                        MenuPrincipal();
                        break;

                case '7':   // opcion 7
                        abrirNavegador("./doc/TablaPotencias2.html");
                        cls();
                        MenuPrincipal();
                        break;

                case '8':   // opcion 8
                        abrirNavegador("./doc/Ejercicios.html");
                        cls();
                        MenuPrincipal();
                        break;

                case '9':   // opcion salir
                        System.out.println("Opcion salir");
                        salir = true;
                        break;

                default:    // opcion erronea
                        System.out.println("Opcion incorrecta.");

            }  // fin switch()
        }  // fin while()
    }

    // Borra la pantalla en la consola de textos
    public void cls()
    {
        int prog;

        try {
            if(so_codigo == 1)
                prog = new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            else
            {
                prog = new ProcessBuilder("clear").inheritIO().start().waitFor();
            }
        } catch (IOException | InterruptedException ex) {
            System.err.println("ERROR: No se pudo ejecutar el proceso.");
            System.err.println(ex.getMessage());
        }
    }

    // Hace sonar un pitido en el parlante de la PC
    public void beep()
    {
        java.awt.Toolkit.getDefaultToolkit().beep();
    }

    public void leaTecla(char tecla)
    {
	char opcion = 0;

        System.out.print("\nPresione tecla ["+ tecla +"] para regresar al menú principal...");

        while (true) {
            try {
                opcion = (char)System.in.read();
                if(Character.toLowerCase(opcion) == tecla)
                    break;
                else
                {
                    if(opcion < ' ')
                        continue;

                    System.out.println("Opcion incorrecta.");
                    System.out.flush();
                    opcion = 0;
                }

            } catch (IOException ex) {
                System.getLogger(NumeracionBinaria.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
            }
        }  // fin while()
    }

    public void MenuPrincipal()
    {
        System.out.println("\t    << Menú principal >>");
        System.out.println();

        System.out.println("\t[1] Tabla de conversión Decimal -- Binario");
        System.out.println("\t[2] Convertir Decimal -- Binario");
        System.out.println("\t[3] Convertir Binario -- Decimal");
        System.out.println("\t[4] Cálculos aritméticos");
        System.out.println("\t[5] Calculadora");
        System.out.println("\t[6] Aprende el sistema binario en Internet");
        System.out.println("\t[7] Unidades de medida de almacenamiento de datos");
        System.out.println("\t[8] Laboratorio de prácticas");

        System.out.println("\t[9] Salir.");
    }

    public void TablaConversion()
    {
        System.out.println("<< Tabla de conversión Decimal - Binario >>");
        System.out.println();

        for (int i = 0; i < 16; i++) {
            System.out.println(i + " --> " + Integer.toBinaryString(i));
        }

        leaTecla('r');
        System.out.println("Regresando a menu principal...");
    }

    // Lee un nro. decimal que ingresa por teclado y lo convierte a un nro. binario.
    public void Decimal_Binario()
    {
        int dato = 0;
        Scanner teclado = new Scanner(System.in);

        System.out.println("<< Convertir un nº decimal entero, positivo/negativo, a un nº binario >>");
        System.out.println();

        do
        {
            System.out.println("Máximo permitido: " + Integer.MAX_VALUE);
            System.out.println("AVISO: Para terminar la entrada de datos ingrese 0.\n");
            System.out.print("número: ");

            try {
                    dato = teclado.nextInt();
            } catch (InputMismatchException ex) {
                System.out.println("¡ERROR!");
                teclado.next();
                dato = -1;
            }

            System.out.println("En binario es: " + Integer.toBinaryString(dato));
            System.out.println();
        } while(dato != 0);

        leaTecla('r');
        System.out.println("Regresando a menu principal...");
    }

    // Lee un nro. binario que ingresa por teclado y lo convierte a un nro. decimal.
    public void Binario_Decimal()
    {
        int dato = 0;
        Scanner teclado = new Scanner(System.in);

        System.out.println("<< Convertir un nº binario a un nº decimal entero, positivo/negativo >>");
        System.out.println();

        do
        {
            System.out.println("Máximo permitido: " + Integer.toBinaryString( Integer.MAX_VALUE));
            System.out.println("AVISO: Para terminar la entrada de datos ingrese 0.\n");
            System.out.print("número: ");

            try
            {
                dato = teclado.nextInt(2);
            }
            catch (InputMismatchException ex)
            {
                System.out.println("¡ERROR!");
                teclado.next();
                dato = -1;
            }

            System.out.println("En decimal es: " + dato);
            System.out.println();

        } while (dato != 0);

        leaTecla('r');
        System.out.println("Regresando a menu principal...");
    }

    public void operarCalculos()
    {
        int opcion_seleccionada = 0;
        Scanner teclado = new Scanner(System.in);

        System.out.println("\t    << Cálculos aritméticos >>");
        System.out.println();

	do
	{
	    System.out.println(" 1) Suma binaria");
	    System.out.println(" 2) Resta binaria");
	    System.out.println(" 3) Producto binario");
	    System.out.println(" 4) Cociente binario");

	    System.out.println(" 0) Salir");

	    System.out.print("Operacion? ");
	    try
            {
                opcion_seleccionada = teclado.nextInt();

                if(opcion_seleccionada == 1)
                    suma_binaria();
                else
                {
                    if(opcion_seleccionada == 2)
                        resta_binaria();
                    else
			if(opcion_seleccionada == 3)
			  producto_binario();
			else
			  if(opcion_seleccionada == 4)
			    cociente_binario();
			  else
			    if(opcion_seleccionada != 0)
				System.out.println("Opcion incorrecta!");
                }
            }
            catch(InputMismatchException ex)
            {
                System.err.println("¡ERROR!");
                System.err.println("Entrada incorrecta.");

                teclado.next();
                opcion_seleccionada = -1;
            }

            System.out.println();
	} while(opcion_seleccionada != 0);

        leaTecla('r');
        System.out.println("Regresando a menu principal...");
    }

    public void suma_binaria()
    {
            int op1;
            int op2;
            int resultado;

        Scanner teclado = new Scanner(System.in);
        System.out.println("<< Suma binaria >>");

        System.out.print("1º operando: ");
        op1 = teclado.nextInt(2);

        System.out.print("2º operando: ");
        op2 = teclado.nextInt(2);
        resultado = op1 + op2;		// Efectúa la suma

        System.out.println("Resultado = " + Integer.toBinaryString(resultado) + "<>Decimal = " + resultado);
    }

    public void resta_binaria()
    {
            int op1;
            int op2;
            int resultado;

        Scanner teclado = new Scanner(System.in);
        System.out.println("<< Resta binaria >>");

        System.out.print("1º operando: ");
        op1 = teclado.nextInt(2);

        System.out.print("2º operando: ");
        op2 = teclado.nextInt(2);
        resultado = op1 - op2;		// Efectúa la resta

        System.out.println("Resultado = " + Integer.toBinaryString(resultado) + "<>Decimal = " + resultado);
    }

    public void producto_binario()
    {
            int op1;
            int op2;
            int resultado;

        Scanner teclado = new Scanner(System.in);
        System.out.println("<< Producto binario >>");

        System.out.print("1º operando: ");
        op1 = teclado.nextInt(2);

        System.out.print("2º operando: ");
        op2 = teclado.nextInt(2);
        resultado = op1 * op2;		// Efectúa la multiplicación

        System.out.println("Resultado = " + Integer.toBinaryString(resultado) + "<>Decimal = " + resultado);
    }

    public void cociente_binario()
    {
            int op1;
            int op2;
            int resultado;

        Scanner teclado = new Scanner(System.in);
        System.out.println("<< Cociente binario >>");

        System.out.print("1º operando: ");
        op1 = teclado.nextInt(2);

        System.out.print("2º operando: ");
        op2 = teclado.nextInt(2);
        resultado = op1 / op2;		// Efectúa la división

        System.out.println("Resultado = " + Integer.toBinaryString(resultado) + "<>Decimal = " + resultado);
    }

    // Abre la calculadora
    // En Windows: calc.exe
    // En Linux: kcalc
    public void abrirCalculadora()
    {
        int prog;
        System.out.println(so_codigo);

        try {
            if (so_codigo == 1)
                prog = new ProcessBuilder("calc.exe").inheritIO().start().waitFor();
            else
                prog = new ProcessBuilder("/bin/sh","-c","/usr/bin/kcalc &").inheritIO().start().waitFor();

            System.out.println("Status="+prog);

        } catch (IOException | InterruptedException ex) {
            System.err.println("ERROR: No se pudo abrir la calculadora.");
            System.err.println(ex.getMessage());
        }

        leaTecla('r');
        System.out.println("Regresando a menu principal...");
    }

    // Abre una página web mediante el navegador del S.O.
    public void abrirNavegador(String url)
    {
        int prog;

        try {
            if(so_codigo == 1)
                prog = new ProcessBuilder("cmd.exe","/c","start", url).inheritIO().start().waitFor();
            else
                prog = new ProcessBuilder("/usr/bin/xdg-open", url).inheritIO().start().waitFor();

            System.out.println("Status="+prog);

        } catch (IOException | InterruptedException ex) {
            System.err.println("ERROR: No se pudo abrir el navegador.");
            System.err.println(ex.getMessage());
        }

        leaTecla('r');
        System.out.println("Regresando a menu principal...");
    }

    // Entrada principal al programa 'NumeracionBinaria.jar'
    public static void main(String[] args)
    {
        int mensaje_info = JOptionPane.INFORMATION_MESSAGE;
        String titulo = "Sistema de numeración binaria";
        String mensaje = "¡Bienvenido a la aplicación NumeracionBinaria!\n¿Listo para aprender?";

        JOptionPane.showMessageDialog(null, mensaje, titulo, mensaje_info);
        NumeracionBinaria programa = new NumeracionBinaria();
        programa.ejecutar();

        System.out.println("Finalizado.");
    }  // --fin main()--
}
// __________::__________