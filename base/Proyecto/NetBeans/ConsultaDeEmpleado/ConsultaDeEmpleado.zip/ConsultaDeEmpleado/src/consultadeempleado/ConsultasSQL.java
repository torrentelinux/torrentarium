//
// ConsultaDeEmpleado.java
// Eugenio Mart�nez - Abril de 2025
//

package consultadeempleado;

import java.sql.*;
import java.util.Scanner;

/**
 *
 * @author Octulio Bilet�n
 */
public class ConsultasSQL {
    private static void printMessage(String msg) {
        System.out.println(msg);
    }

    public static void printTitle(String txt) {
        System.out.println("[" + txt + "]");
    }

    public static String input(String txt) {
        Scanner entrada = new Scanner(System.in);
        String entrada_datos;

        System.out.print(txt);
        entrada_datos = entrada.nextLine();

        return entrada_datos;
    }

    /**
     * Efectua una consulta en 'Persona' para mostrar datos del empleado.
     * @param txt_consulta
     * @return
     * @throws ClassNotFoundException
     */
    public static boolean consultarApellido(String txt_consulta) throws ClassNotFoundException {
        boolean devuelve;
        boolean hallado;
        int ncol;
        int i;
        String sqlConsulta;
        String[] datoColumna;

        try
        {
            /* Datos de conexion para el servidor Postgresql
            String jdbcUrl = "jdbc:postgresql://localhost:5432/persona";
            String username = "postgres";
            String keypass = (new StringBuffer("sergtsop").reverse()).toString();
            */

            // Datos de conexion para el servidor MySQL
            String jdbcUrl = "jdbc:mysql://localhost:3306/persona";
            String username = "root";
            String keypass = "";

            printMessage("Estableciendo conexi�n a base de datos 'Persona'...");

            // Register the PostgreSQL driver
            //Class.forName("org.postgresql.Driver");

            // Register the MySQL driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Abre la conexion a la base de datos.
            Connection conexion = DriverManager.getConnection(jdbcUrl, username, keypass);

            System.out.println("Consultando en la tabla 'Empleado': " + txt_consulta + "\n");
            Statement sentencia = conexion.createStatement();

            sqlConsulta = "select * from empleado where apellido = '" + txt_consulta + "'";
            ResultSet resultado_final = sentencia.executeQuery(sqlConsulta);

            hallado = false;
            ncol = 0;
            i = 1;
            datoColumna = new String[4];

            // Visualiza los datos del empleado en pantalla
            while(resultado_final.next())
            {
                while(ncol < 4)
                    datoColumna[ncol++] = resultado_final.getString(ncol);

                System.out.println("---Ficha del personal---");
                    System.out.println("Nombre  : " + datoColumna[i].substring(0, 1).toUpperCase() + datoColumna[i++].substring(1));
                    System.out.println("Apellido: " + datoColumna[i].substring(0, 1).toUpperCase() + datoColumna[i++].substring(1));
                    System.out.printf("Sueldo $:%13.12s\n", datoColumna[i]);
                System.out.println("------------------------");

                hallado = true;  // Empleado encontrado
            }

            // Cierra la conexion
            resultado_final.close();
            sentencia.close();
            conexion.close();

            devuelve = hallado;
        }
        catch(SQLException ex)
        {
            System.err.println("[Error] " + ex.getMessage());
            System.err.flush();

            devuelve = false;
        }

        return devuelve;
    }

    /**
     * Punto de entrada a la aplicaci�n 'ConsultaDeEmpleado.jar'.
     * @param args Argumentos que vienen desde la l�nea de comandos.
     * @throws java.lang.ClassNotFoundException
     */
    public static void main(String[] args) throws ClassNotFoundException {
        boolean estado;
        String consulta;

        printTitle("Consulta de Empleado al servidor SQL");
        consulta = input("Ingrese el apellido de la persona\n>> ");

        System.out.println("Apellido ingresado: " + consulta);

        // Efectua la consulta
        estado = consultarApellido(consulta);
        if(estado)
            System.out.println("Ok.");
        else
            System.out.println("No encontrado.");
    }
}
