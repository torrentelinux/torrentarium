// Proyecto : AgendaPersonal
// Módulo   : GuardarJTable.java
// Autor    : Octulio Biletán * Octubre de 2024.
// Propósito: Agenda Personal en Java/Swing.
//            Guarda los datos en un fichero de textos.

package agendapersonal;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.*;
import javax.swing.table.TableModel;

/**
 *
 * @author octulio biletán
 */
public class GuardarJTable
{
    public void guardarDatos(JTable table, String rutaArchivo)
    {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaArchivo)))
        {
            TableModel model = table.getModel();

            // Escribir encabezados
            for (int i = 0; i < model.getColumnCount(); i++)
            {
                writer.write(model.getColumnName(i) + (i < model.getColumnCount() - 1 ? "," : ""));
            }
            writer.newLine();

            // Escribir datos
            for (int i = 0; i < model.getRowCount(); i++)
            {
                for (int j = 0; j < model.getColumnCount(); j++)
                {
                    writer.write(model.getValueAt(i, j).toString() + (j < model.getColumnCount() - 1 ? "," : ""));
                }
                writer.newLine();
            }
        }
        catch(IOException e)
        {
            System.out.println("Error: " + e.getLocalizedMessage());
        }
    }
}
