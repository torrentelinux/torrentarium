// Proyecto : AgendaPersonal
// Módulo   : CargarJTable.java
// Autor    : Octulio Biletán * Octubre de 2024.
// Propósito: Agenda Personal en Java/Swing.
//            Lee los datos desde un fichero de textos.

package agendapersonal;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author octulio biletán
 */
public class CargarJTable
{
    public void cargarDatos(JTable table, String rutaArchivo)
    {
        try(BufferedReader reader = new BufferedReader(new FileReader(rutaArchivo)))
        {
            String linea;
            String[] datos;
            DefaultTableModel modelo = (DefaultTableModel)table.getModel();

            // Leer encabezados
            linea = reader.readLine();

            // Limpia la tabla
            modelo.setRowCount(0);

            // Leer las siguientes líneas para los datos
            while((linea = reader.readLine()) != null) 
            {
                // Suponiendo que los datos están separados por comas
                datos = linea.split(","); 

                // Añade los datos a la siguiente fila de la tabla
                modelo.addRow(datos);
            }
        }
        catch(IOException e)
        {
            System.out.println("Error: " + e.getLocalizedMessage());
        }
    }
}
