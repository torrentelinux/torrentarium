/*-----------------------------------------------
Octulio Bilet�n * Octubre de 2024.
Desarrollo para Java junto con Apache NetBeans IDE.
Soporte multiplataforma: Linux y Windows.
Sitio base: https://sites.google.com/site/torrentewindows/home

En java �c�mo puedo leer datos de un fichero de textos y cargarlos en un jtable con 4 columnas y 20 filas?
Modelo 1
*/
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class CargarJTable {
    public static void main(String[] args) {
        // Crear el modelo de la tabla
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Columna 1");
        modelo.addColumn("Columna 2");
        modelo.addColumn("Columna 3");
        modelo.addColumn("Columna 4");

        // Leer el fichero de texto
        try (BufferedReader br = new BufferedReader(new FileReader("ruta/del/fichero.txt"))) {
            String linea;
            int contador = 0;

            while ((linea = br.readLine()) != null && contador < 20) {
                String[] datos = linea.split(","); // Suponiendo que los datos est�n separados por comas
                modelo.addRow(datos);
                contador++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Crear el JTable
        JTable tabla = new JTable(modelo);
        JScrollPane scrollPane = new JScrollPane(tabla);
        JFrame frame = new JFrame("Ejemplo de JTable");
        frame.add(scrollPane);
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
/*----------------------------------------------------------
Modelo 2
*/
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class CargarJTable {
    public static void main(String[] args) {
        // Crear el modelo de la tabla
        DefaultTableModel modelo = new DefaultTableModel();

        // Leer el fichero de texto
        try (BufferedReader br = new BufferedReader(new FileReader("ruta/del/fichero.txt"))) {
            String linea;

            // Leer la primera l�nea para los nombres de las columnas
            if ((linea = br.readLine()) != null) {
                String[] encabezados = linea.split(","); // Suponiendo que los encabezados est�n separados por comas
                for (String encabezado : encabezados) {
                    modelo.addColumn(encabezado.trim());
                }
            }

            // Leer las siguientes l�neas para los datos
            int contador = 0;
            while ((linea = br.readLine()) != null && contador < 20) {
                String[] datos = linea.split(","); // Suponiendo que los datos est�n separados por comas
                modelo.addRow(datos);
                contador++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Crear el JTable
        JTable tabla = new JTable(modelo);
        JScrollPane scrollPane = new JScrollPane(tabla);
        JFrame frame = new JFrame("Ejemplo de JTable");
        frame.add(scrollPane);
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
