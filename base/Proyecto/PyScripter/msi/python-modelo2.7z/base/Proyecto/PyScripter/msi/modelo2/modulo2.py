#-------------------------------------------------------------------------------
# Name:        modulo2.py
# Purpose:
#
# Author:      admin
#
# Created:     18/01/2024
# Copyright:   (c) admin 2024
# Licence:     Software Libre
#-------------------------------------------------------------------------------
# Importa todo lo que tiene el programa AplicacionPrincipal.py
import AplicacionPrincipal as ap

def inicio():
    print(ap.sistema_autor, ap.sistema_fecha)
    print("Licencia " + ap.sistema_licencia)
