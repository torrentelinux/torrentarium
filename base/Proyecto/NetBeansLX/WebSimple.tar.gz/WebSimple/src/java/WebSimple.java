// Programa  : WebSimple.java
// Autor     : Eugenio Martínez - Nov. de 2021
// Propósito : Crear dinámicamente una página HTML mediante la clase HTML.
//             Colocar un contador en dicha página.
// Comentario: 1ro. debe habilitar el servicio Apache Tomcat en su S.O.
//             Ejecute el proyecto en su navegador de HTML y escriba lo siguiente en la barra de direcciones:
//             http://127.0.0.1:8080/WebSimple/
//             Funciona en CentOS Linux 7 y en Windows.
// Referencias: https://es.wikipedia.org/wiki/HTML
// __________________________________________________________________________

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Developer
 */
public class WebSimple extends HttpServlet
{
    int cuenta = 1;

    /**
     * Es llamado por el servidor (a través del método de servicio) para permitir que un <i>'servlet'</i> maneje una solicitud tipo <i>'GET'</i>.
     *
     * @param solicita Recibe info.
     * @param responde Envía info.
     * @throws javax.servlet.ServletException
     * @throws IOException
     */
    public void doGet(HttpServletRequest solicita, HttpServletResponse responde) throws ServletException, IOException
    {
        HTML html = new HTML(responde);
        String titulo = "Cuenta...";

        // Aquí comienza el contenido html a publicar en el navegador de páginas HTML
        html.openHtml();

        html.openHead();

        html.setGenerator("Biblioteca de clase HTML, ver. 1.0, ed. Java");
        html.setDescription("WebSimple: programado en Java.");
        html.setAuthor("Eugenio Martínez - Nov. de 2021");
        html.putTitle(titulo);

        html.closeHead();

        html.openBody();

        // Coloca el título muy grande y centrado en la pantalla.
        html.putTitle1(html.alignCenter(titulo));
        html.putTitle1("Presione F5 para actualizar contenido de la página.");

        html.putTextBr("Cuenta tiene: " + cuenta);

        html.putText("Cada vez que se presiona la ");
        html.putTextColor("yellow", "rgb(2, 2, 255)", "tecla <b>F5</b>");
        html.putTextBr(", el contador se incrementa en una unidad.");

        // Coloca una línea horizontal
        html.putHorizontalLine("100");

        html.putTextColor("yellow", "black", html.underline("Información adicional"));
        html.putTextBr("");
        html.putTextBr(html.bold("Nombre equipo local: ")  + solicita.getLocalName());
        html.putTextBr(html.bold("IP equipo local: ")      + solicita.getLocalAddr());
        html.putTextBr(html.bold("Puerto equipo local: ")  + solicita.getLocalPort());
        html.putTextBr("_____________________");
        html.putTextBr("Nombre del servidor: "  + solicita.getServerName());
        html.putTextBr("Equipo remoto: "        + solicita.getRemoteHost());
        html.putTextBr("IP equipo remoto: "     + solicita.getRemoteAddr());
        html.putTextBr("Puerto equipo remoto: " + solicita.getRemotePort());
        html.putTextBr("Usuario remoto: "       + solicita.getRemoteUser());

        html.closeBody();

        // Aquí termina el contenido html.
        html.closeHtml();

        // Se incrementa la variable en una unidad.
        cuenta++;
    }
}
