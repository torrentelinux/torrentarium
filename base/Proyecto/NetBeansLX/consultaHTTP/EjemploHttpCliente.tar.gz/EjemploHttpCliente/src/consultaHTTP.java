// consultaHTTP.java
// Octulio Biletán - Diciembre de 2025
// Licencia: Software Libre - GNU/GPL v3
// Referencias: leer documento texto 'consultaHTTP.txt'
// -_________________________________________________________-

import java.io.IOException;
import java.net.URI;
import java.net.UnknownHostException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;

// Código de error
static private int errno;

@SuppressWarnings("empty-statement")
void main(String args[]) throws InterruptedException
{
    boolean muestre_ayuda = false;
    int status = 0;
    String sitio = "www.ejemplo.net";
    String proto = "https://";
    String sop = System.getProperty("os.name");
    String codigo_texto = "";
    String datosRecibidos = "[sin contenidos]";
    String estadoClienteHTTP = "[sin contenidos]";
    String estadoPeticionHTTP = "[sin contenidos]";
    InetAddress d = null;

    errno = 0;
    System.out.println("consultaHTTP 1.0.2025 (" + sop + ").\n");

    if(args.length > 0)
    {
        if(args[0].contains("http://"))
        {
          proto = "http://";
          sitio = args[0].substring(7);
        }
        else
        {
            if(args[0].contains("https://"))
            {
                proto = "https://";
                sitio = args[0].substring(8);
            }
            else
                sitio = args[0];
        }
    }
    else
        muestre_ayuda = true;

    try
    {
        d = InetAddress.getByName(sitio);
    }
    catch(UnknownHostException x)
    {
        System.out.println("{Error} " + x.getMessage() + ".");
        status = 4;
    }

    try(HttpClient cliente = HttpClient.newHttpClient())
    {
        estadoClienteHTTP = cliente.toString();

        HttpRequest peticion = HttpRequest.newBuilder()
                .uri(URI.create(proto + sitio))
                .GET() // es un 'GET' por omisión
                .build();

        estadoPeticionHTTP = peticion.toString();

        HttpResponse<Void> respuesta = cliente.send(peticion, HttpResponse.BodyHandlers.discarding());

        datosRecibidos = respuesta.headers().toString();

        System.out.println("Dirección: " + respuesta.uri().toURL());
        System.out.println("Sitio: " + sitio);
        System.out.println("IPv4: " + d.getHostAddress());
        System.out.println("Fecha: " + respuesta.headers().firstValue("date").get());
        System.out.println("Servidor: " + respuesta.headers().firstValue("server").get());
        System.out.println("Tam. contenido: " + respuesta.headers().firstValue("content-length").get());
        System.out.println("Cookie: " + respuesta.headers().firstValue("set-cookie").get());
        System.out.println("Comando: " + respuesta.headers().firstValue("allow").get());

        errno = respuesta.statusCode();

        switch(errno)
        {
            case 200: codigo_texto = "Ok.";
                break;
            case 301: codigo_texto = "Moved Permanently.";
                break;
            case 302: codigo_texto = "Found.";
                break;
            case 303: codigo_texto = "See Other (since HTTP/1.1)";
                break;
            case 403: codigo_texto = "Forbidden.";
                break;
            case 429: codigo_texto = "Too many requests.";
                break;
            default: perror("(Error) código de estado: ");
        }

        System.out.println("Status: " + codigo_texto);
    }  // fin try()
    catch(NoSuchElementException x)
    {
        System.out.println("Elemento: 'desconocido'.");
        System.out.println("[Datos recibidos]\n" + datosRecibidos);
        status = 1;
    }
    catch(IllegalArgumentException x)
    {
        System.out.println("<Error> El esquema URI no está soportado: " + sitio);
        System.out.println(x.getMessage());
        status = 2;
    }
    catch(IOException x)
    {
        String condicion = x.getMessage();

        if(condicion == null)
            condicion = "Estado: " + "Fuera de línea/Inexistente" + "; " + sitio;
        else
            condicion = condicion  + "; " + sitio;

        System.out.println("[Error] <" + condicion + ">");
        System.out.println("Estado cliente http: " + estadoClienteHTTP);
        System.out.println("Estado petición http: " + estadoPeticionHTTP);
        System.out.println("Datos recibidos:\n" + datosRecibidos);
        status = 3;
    }

    if(d != null)
    {
        System.out.println("Analizando los puertos TCP: " + d);
        int dato = 0, cpuerto = 0;
	String tmp_ip = d.getHostAddress();

        // Consultar por puertos HTTP en /etc/services
        // Rango válido de puertos 0~65535
        // tcp/8000 -> jwebserver
        int npuerto[] = { 0, 1, 80, 280, 443, 488, 593, 623, 664, 777,
                          4180, 4848, 5443, 7443, 8000, 8080, 8118, 8443, 8883, 8990,
                          9090, 9762, 10000, 65535
                        };

        for(int p = 0; p < npuerto.length; p++)
        {
            dato = infoPuertoTCP(tmp_ip, npuerto[p], 1);
            if(dato == 1)
            {
                System.out.println("  Puerto TCP/" + npuerto[p] + ": " + dato);
                cpuerto++;
            }
        }

        System.out.println("Se encontraron " + cpuerto + " puertos abiertos.");
    }  // Fin if()

    if(muestre_ayuda)
    {
        mostrarAyuda();
    }

    System.exit(status);  // Regresa al S.O. con un código de salida
}

private int infoPuertoTCP(String ipdir, int p, int furtivo) throws InterruptedException
{
        Socket clienteRemoto;
        int estadoPuerto = 1;  // Servicio abierto en el puerto consultado

    try
    {
        clienteRemoto = new Socket();
        clienteRemoto.connect(new InetSocketAddress(ipdir, p), 1500);

        Thread.sleep(500);
        clienteRemoto.close();
    }
    catch(UnknownHostException ex)
    {
        estadoPuerto = 2;  // Dirección desconocida
    }
    catch(IOException ex)
    {
        if(furtivo != 1)
            System.out.println("<·>" + ex.getMessage());

        estadoPuerto = 0;  // Rechazado, bloqueado, tiempo de espera agotado
    }

    return estadoPuerto;
}

private void perror(String s)
{
    throw new AssertionError(s + errno, null);
}

// Muestra una ayuda en pantalla de texto
private void mostrarAyuda()
{
    System.out.println("\nSe efectúa una consulta sobre el servicio de información ofrecido en el servidor http/https\n");

    System.out.println("<Ayuda>");
    System.out.println("Uso general: consultaHTTP [nombre sitio] | [dir. IP]");
    System.out.println("Use de la siguiente manera:");
    System.out.println("(1) Nombre completo del sitio, por ejemplo 'www.kernel.org'");
    System.out.println("(2) Protocolo HTTP más nombre completo del sitio, por ejemplo 'http://www.kernel.org'");
    System.out.println("(3) Protocolo HTTP seguro más nombre completo del sitio, por ejemplo 'https://www.kernel.org'");
    System.out.println("(4) Dir. IP del sitio, por ejemplo '1.1.1.1'");
    System.out.println("(5) Protocolo HTTP más dir. IP del sitio, por ejemplo 'http://1.1.1.1'");
    System.out.println("(6) Protocolo HTTP seguro más dir. IP del sitio, por ejemplo 'https://1.1.1.1'");

    System.out.println("\nSi estás en Linux/Bash podés consultar el código devuelto por la aplicación:");
    System.out.println("\techo $?");
    System.out.println("Código 0: Ok.");
    System.out.println("Cualquier otro código se considera que hubo un error.");
}
