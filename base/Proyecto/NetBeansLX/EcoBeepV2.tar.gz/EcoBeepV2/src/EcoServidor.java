// EcoServidor.java
// Octulio Biletán
// Servidor eco que escucha y responde peticiones por el puerto nº 7.
// Versión 2.4 ** 04-Abril-2022
// Desarrollada con la biblioteca JAVA JDK 11.

/*
Referencias:
https://docs.oracle.com/javase/tutorial/networking/sockets/readingWriting.html
https://docs.oracle.com/javase/tutorial/displayCode.html?code=https://docs.oracle.com/javase/tutorial/networking/sockets/examples/EchoClient.java
https://docs.oracle.com/javase/tutorial/displayCode.html?code=https://docs.oracle.com/javase/tutorial/networking/sockets/examples/EchoServer.java
https://datatracker.ietf.org/doc/html/rfc862
*/

import java.awt.Toolkit;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

import java.util.Calendar;

public class EcoServidor
{
    String presentar_mensaje;

    EcoServidor()
    {
        presentar_mensaje = "Iniciando servidor EcoBeep...\n" +
                            "Ordenes aceptadas: beep y exit.\n" +
                            "Se acepta cualquier secuencia de caracteres UNICODE\n" +
                            "que provengan del puerto TCP/7 y los re-envía al equipo emisor.";
        System.out.println(presentar_mensaje);
    }

    void comandoExit(PrintWriter sr)
    {
        sr.println("\nOk.\n");
        sr.flush();

        System.out.println("Tiempo: " + Calendar.getInstance().getTime());
        System.out.println("\nSaliendo...");
        System.exit(0);
    }

    void comandoBeep(Socket cc)
    {
        InetAddress clienteIP;

        System.out.print("\u0007");
        System.out.flush();

        Toolkit.getDefaultToolkit().beep();

        clienteIP = cc.getInetAddress();
        System.out.println("<Timbre>" + " desde: " + clienteIP.getHostAddress() + "<>" + "Nombre equipo: " + clienteIP.getHostName());
    }

    public static void main(String[] args) throws IOException
    {
        if(args.length != 1)
        {
            System.err.println("Uso: java EcoServidor <puerto>");
            System.exit(1);
        }

        int numPuerto = Integer.parseInt(args[0]);
        EcoServidor eco1 = new EcoServidor();

        try (
            ServerSocket conectorServidor = new ServerSocket(numPuerto);
            Socket conectorCliente = conectorServidor.accept();
            PrintWriter salidaRemota = new PrintWriter(conectorCliente.getOutputStream(), true);
            BufferedReader entradaLocal = new BufferedReader(new InputStreamReader(conectorCliente.getInputStream()));
        )
        {
            InetAddress servidorIP;
            String entradaUsuario;

            servidorIP = conectorServidor.getInetAddress();

            System.out.println("Tiempo: " + Calendar.getInstance().getTime());
            System.out.println("<Servidor> Dirección IP: " + servidorIP
                    + "<>"
                    + "Nº puerto: " + conectorServidor.getLocalPort()
                    + "<>"
                    + "Nombre: " + servidorIP.getCanonicalHostName());

            while((entradaUsuario = entradaLocal.readLine()) != null)
            {
                salidaRemota.println(entradaUsuario);
                salidaRemota.flush();

                if(entradaUsuario.compareTo("exit") == 0)
                {
                    eco1.comandoExit(salidaRemota);
                }

                if(entradaUsuario.compareTo("beep") == 0)
                {
                    eco1.comandoBeep(conectorCliente);
                }

                System.out.println("Mensaje recibido-->> " + entradaUsuario);
            }
        }
        catch(IOException e)
        {
            System.err.println("AVISO: Excepción capturada cuando trataba de escuchar por el puerto " + numPuerto + " o porque estaba escuchando.");
            System.err.println(e.getMessage());
        }
        catch(NullPointerException e)
        {
            System.err.println("<ERROR>" + e.getMessage());
        }

        System.out.println("Tiempo de interrupción: " + Calendar.getInstance().getTime());
        System.out.println("Comunicación interrumpida en el servidor.");
    }
}
