// Proyecto : NumeracionBinaria
// Paquete  : numeracionbinaria
// Programa : NumeracionBinaria.java
// Autor    : Octulio Biletán - Junio de 2026
// Objetivos: Proporcionar un software educativo para la enseñanza del sistema de numeración binaria.
// Notas    : El proyecto ha sido construído en NetBeans IDE.
// Licencia : Software Libre.
// Referencias:
//	https://es.wikipedia.org/wiki/Código_binario

package numeracionbinaria;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 * Clase principal de la aplicación 'NumeracionBinaria.jar'.
 * @author Octulio Biletán
 * Fecha: 4/6/2026.
 */
public class NumeracionBinaria
{
    /**
     * Clase Color.<br>
     * Permite asignar colores al texto como así también para el fondo del mismo.<br>
     * @author Octulio Biletán
     * Fecha: 12/6/2026.
     */
    public class Color
    {
        /**
         * Restablece los 'atributos normales del color' para el texto y para el fondo.
         * @return Los códigos ANSI/ESC de atributos normales del color.
         */
        public static String AtributosNormales()
        {
            return "\033[0;39;49m";
        }

        /**
         * Fija color blanco intenso para el texto y color verde para el fondo.
         * @return Los códigos ANSI/ESC de atributos de color para poner sobre una secuencia de caracteres.
         */
        public static String BlancoIntensoSobreVerde()
        {
            return "\033[1;37;42m";
        }

        /**
         * Fija color negro para el texto y color verde para el fondo.
         * @return Los códigos ANSI/ESC de atributos de color para poner sobre una secuencia de caracteres.
         */
        public static String NegroSobreVerde()
        {
            return "\033[0;30;42m";
        }
    }

    private boolean salir;                      // salgo o no salgo?
    private char opcion;                        // contiene la opción que ha ingresado el usuario por el teclado.
    private final int so_codigo;                // 1=windows; 2=linux; -1=desconocido
    private final String tituloPrincipal;	// título principal de la aplicación
    private String so_nombre_completo;          // nombre completo del S.O.
    private final String []nombre_calculadora;  // lista de calculadoras para Linux

    public NumeracionBinaria()
    {
        opcion = 0;
        salir = false;
        so_nombre_completo = "desconocido";

        nombre_calculadora = new String[3];

        if(esWindows())
        {
            so_codigo = 1;
        }
        else
        {
            if(esLinux())
                so_codigo = 2;
            else
                so_codigo = -1;
        }

        tituloPrincipal = "Sistema de Numeración Binaria";

        // Inicializa la lista de calculadoras de Linux
        nombre_calculadora[0] = "/usr/bin/kcalc";
        nombre_calculadora[1] = "/usr/bin/gnome-calculator";
        nombre_calculadora[2] = "/usr/bin/galculator";
    }

    public boolean esWindows()
    {
        String so_nombre = System.getProperty("os.name").toLowerCase();

	// Recupera de la JVM el nombre real del S.O.
        so_nombre_completo = System.getProperty("os.name");
        return so_nombre.contains("windows");
    }

    public boolean esLinux()
    {
        String so_nombre = System.getProperty("os.name").toLowerCase();

	// Recupera de la JVM el nombre real del S.O.
        so_nombre_completo = System.getProperty("os.name");
        return so_nombre.contains("linux");
    }

    // Devuelve el nombre del S.O.
    public String nombreSistemaOp()
    {
        String datos_leidos = "desconocido";
        File sistema;
        FileReader leeArchivo;

        // accede al archivo /etc/system-release
	// alternativa: /etc/os-release y fijarse en 'NAME='
	// alternativa: /etc/lsb-release y fijarse en 'PRETTY_NAME='
        sistema = new File("/etc/system-release");

        if(sistema.exists() == true)
        {
            try {
                // abre el archivo /etc/system-release
                leeArchivo = new FileReader(sistema.getAbsolutePath());

                try {
                    char[] datos = new char[1024];
                    int ndatos;

                    // lee el archivo /etc/system-release
                    ndatos = leeArchivo.read(datos);

                    datos_leidos = String.valueOf(datos);

                    leeArchivo.close();
                } catch (IOException ex) {
                    System.err.println("Error de lectura.");
                    Logger.getLogger(NumeracionBinaria.class.getName()).log(Level.SEVERE, null, ex);
                }

            } catch (FileNotFoundException ex) {
                System.err.println("Error de acceso.");
                Logger.getLogger(NumeracionBinaria.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        else
            datos_leidos = System.getProperty("os.name");

        return datos_leidos;
    }

    // Borra la pantalla en la consola de textos
    public void cls()
    {
        int prog;

        try {
            if(so_codigo == 1)
                prog = new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            else
            {
                // Borra la pantalla de textos mediante una secuencia de códigos escape
                System.out.println("\033[2J\033[0;0f");
            }
        } catch (IOException | InterruptedException ex) {
            System.err.println("ERROR: No se pudo ejecutar el proceso.");
            System.err.println(ex.getMessage());
        }
    }

    // Hace sonar un pitido en el parlante de la PC
    public void beep()
    {
        java.awt.Toolkit.getDefaultToolkit().beep();
    }

    public void leaTecla(char tecla)
    {
	char opcion = 0;

        System.out.print("\nPresione tecla ["+ tecla +"] para regresar al menú principal...");

        while (true) {
            try {
                opcion = (char)System.in.read();
                if(Character.toLowerCase(opcion) == tecla)
                    break;
                else
                {
                    if(opcion < ' ')
                        continue;

                    System.out.println("Opcion incorrecta.");
                    System.out.flush();
                    opcion = 0;
                }

            } catch (IOException ex) {
                System.getLogger(NumeracionBinaria.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
            }
        }  // fin while()
    }

    public void TablaConversion()
    {
        System.out.println(Color.NegroSobreVerde());
        System.out.println("<< Tabla de conversión Decimal - Binario >>");
        System.out.println(Color.AtributosNormales());

        System.out.println();

        // Muestra los resultados sobre un espacio de 132 columnas
        for (int i = 0; i < 16; i++) {
	    System.out.printf("| %02d --> %4s", i,Integer.toBinaryString(i));
	    System.out.print(" | " + (i+16) + " --> " + Integer.toBinaryString(i+16));
	    System.out.print(" | " + (i+32) + " --> " + Integer.toBinaryString(i+32));
	    System.out.print(" | " + (i+48) + " --> " + Integer.toBinaryString(i+48));
	    System.out.print(" | " + (i+64) + " --> " + Integer.toBinaryString(i+64));
	    System.out.print(" | " + (i+80) + " --> " + Integer.toBinaryString(i+80));
	    System.out.printf("| %03d --> %s", i+96,Integer.toBinaryString(i+96));
	    System.out.println(" | " + (i+112) + " --> " + Integer.toBinaryString(i+112));
        }

        leaTecla('r');
        System.out.println("Regresando a menu principal...");
    }

    // Lee un nro. decimal que ingresa por teclado y lo convierte a un nro. binario.
    public void Decimal_Binario()
    {
        int dato = 0;
        Scanner teclado = new Scanner(System.in);

        System.out.println(Color.NegroSobreVerde());
        System.out.println("<< Convertir un nº decimal entero, positivo/negativo, a un nº binario >>");
        System.out.println(Color.AtributosNormales());

        System.out.println();

        do
        {
            System.out.println("Máximo permitido: " + Integer.MAX_VALUE);
            System.out.println("AVISO: Para terminar la entrada de datos ingrese 0.\n");
            System.out.print("número: ");

            try {
                    dato = teclado.nextInt();
            } catch (InputMismatchException ex) {
                System.out.println("¡ERROR!");
                teclado.next();
                dato = -1;
            }

            System.out.println("En binario es: " + Integer.toBinaryString(dato));
            System.out.println();
        } while(dato != 0);

        leaTecla('r');
        System.out.println("Regresando a menu principal...");
    }

    // Lee un nro. binario que ingresa por teclado y lo convierte a un nro. decimal.
    public void Binario_Decimal()
    {
        int dato = 0;
        Scanner teclado = new Scanner(System.in);

        System.out.println(Color.NegroSobreVerde());
        System.out.println("<< Convertir un nº binario a un nº decimal entero, positivo/negativo >>");
        System.out.println(Color.AtributosNormales());

        System.out.println();

        do
        {
            System.out.println("Máximo permitido: " + Integer.toBinaryString( Integer.MAX_VALUE));
            System.out.println("AVISO: Para terminar la entrada de datos ingrese 0.\n");
            System.out.print("número: ");

            try
            {
                dato = teclado.nextInt(2);
            }
            catch (InputMismatchException ex)
            {
                System.out.println("¡ERROR!");
                teclado.next();
                dato = -1;
            }

            System.out.println("En decimal es: " + dato);
            System.out.println();

        } while (dato != 0);

        leaTecla('r');
        System.out.println("Regresando a menu principal...");
    }

    public void operarCalculos()
    {
        int opcion_seleccionada = 0;
        Scanner teclado = new Scanner(System.in);

        System.out.println(Color.NegroSobreVerde());
        System.out.println("\t    << Cálculos aritméticos >>");
        System.out.println(Color.AtributosNormales());

        System.out.println();

	do
	{
	    System.out.println(" 1) Suma binaria");
	    System.out.println(" 2) Resta binaria");
	    System.out.println(" 3) Producto binario");
	    System.out.println(" 4) Cociente binario");

	    System.out.println(" 0) Salir");

	    System.out.print("Operacion? ");
	    try
            {
                opcion_seleccionada = teclado.nextInt();

                if(opcion_seleccionada == 1)
                    suma_binaria();
                else
                {
                    if(opcion_seleccionada == 2)
                        resta_binaria();
                    else
			if(opcion_seleccionada == 3)
			  producto_binario();
			else
			  if(opcion_seleccionada == 4)
			    cociente_binario();
			  else
			    if(opcion_seleccionada != 0)
				System.out.println("Opcion incorrecta!");
                }
            }
            catch(InputMismatchException ex)
            {
                System.err.println("¡ERROR!");
                System.err.println("Entrada incorrecta.");

                teclado.next();
                opcion_seleccionada = -1;
            }

            System.out.println();
	} while(opcion_seleccionada != 0);

        leaTecla('r');
        System.out.println("Regresando a menu principal...");
    }

    public void suma_binaria()
    {
            int op1;
            int op2;
            int resultado;
            Scanner teclado;

        teclado = new Scanner(System.in);

        System.out.println(Color.NegroSobreVerde());
        System.out.println("<< Suma binaria >>");
        System.out.println(Color.AtributosNormales());

        System.out.print("1º operando: ");
        op1 = teclado.nextInt(2);

        System.out.print("2º operando: ");
        op2 = teclado.nextInt(2);
        resultado = op1 + op2;		// Efectúa la suma

        System.out.println("Resultado = " + Integer.toBinaryString(resultado) + "<>Decimal = " + resultado);
    }

    public void resta_binaria()
    {
            int op1;
            int op2;
            int resultado;
            Scanner teclado;

        teclado = new Scanner(System.in);

        System.out.println(Color.NegroSobreVerde());
        System.out.println("<< Resta binaria >>");
        System.out.println(Color.AtributosNormales());

        System.out.print("1º operando: ");
        op1 = teclado.nextInt(2);

        System.out.print("2º operando: ");
        op2 = teclado.nextInt(2);
        resultado = op1 - op2;		// Efectúa la resta

        System.out.println("Resultado = " + Integer.toBinaryString(resultado) + "<>Decimal = " + resultado);
    }

    public void producto_binario()
    {
            int op1;
            int op2;
            int resultado;
            Scanner teclado;

        teclado = new Scanner(System.in);

        System.out.println(Color.NegroSobreVerde());
        System.out.println("<< Producto binario >>");
        System.out.println(Color.AtributosNormales());

        System.out.print("1º operando: ");
        op1 = teclado.nextInt(2);

        System.out.print("2º operando: ");
        op2 = teclado.nextInt(2);
        resultado = op1 * op2;		// Efectúa la multiplicación

        System.out.println("Resultado = " + Integer.toBinaryString(resultado) + "<>Decimal = " + resultado);
    }

    public void cociente_binario()
    {
            int op1;
            int op2;
            int resultado;
            Scanner teclado;

        teclado = new Scanner(System.in);

        System.out.println(Color.NegroSobreVerde());
        System.out.println("<< Cociente binario >>");
        System.out.println(Color.AtributosNormales());

        System.out.print("1º operando: ");
        op1 = teclado.nextInt(2);

        System.out.print("2º operando: ");
        op2 = teclado.nextInt(2);

        try
        {
            resultado = op1 / op2;		// Efectúa la división
        }
        catch(ArithmeticException ex)
        {
            System.err.println("ERROR: División por cero no permitido.");
            resultado = 0;
        }

        System.out.println("Resultado = " + Integer.toBinaryString(resultado) + "<>Decimal = " + resultado);
    }

    /**
     * Devuelve la trayectoria completa del programa calculadora que está presente en el S.O. Linux.<br>
     * Se buscan en el S.O. las siguientes calculadoras: <code>kcalc, gnome-calc y galculator</code>.<br>
     * En caso de que el S.O. no cuente con una calculadora, se devolverá la siguiente línea de texto:<br>
     * <code>/usr/bin/printf 'ADVERTENCIA: su S.O. no posee una calculadora.\n'</code>.<br>
     * @return El nombre completo de la calculadora.
     */
    public String linuxCalculadora()
    {
            String sin_calculadora = "/usr/bin/printf 'ADVERTENCIA: su S.O. no posee una calculadora.\n'";
            File prog_calculadora;

        for (int i = 0; i < nombre_calculadora.length ; i++) {
            prog_calculadora = new File(nombre_calculadora[i]);
            if(prog_calculadora.exists() == true)
                return nombre_calculadora[i];
        }

        return sin_calculadora;
    }

    // Abre la calculadora
    // En Windows: calc.exe
    // En Linux: kcalc, etc...
    public void abrirCalculadora()
    {
        int prog;
        String aplicacion;
        String calc = "nodef";

        try {
            if (so_codigo == 1)
            {
                calc = "calc.exe";
                aplicacion = "calc.exe";
                prog = new ProcessBuilder(aplicacion).inheritIO().start().waitFor();
            }
            else
            {
                calc = linuxCalculadora();
                aplicacion = calc + " &";
                prog = new ProcessBuilder("/bin/sh", "-c", aplicacion).inheritIO().start().waitFor();
            }

            System.err.println("Calculadora: " + calc);
            System.err.println("Status=" + prog);

        } catch (IOException | InterruptedException ex) {

            System.out.println("ERROR: No se pudo abrir la calculadora.");
            System.out.println("Comando: " + calc);
            System.err.println(ex.getMessage());

        }

        leaTecla('r');
        System.out.println("Regresando a menu principal...");
    }

    // Abre una página web mediante el navegador del S.O.
    public void abrirNavegador(String url)
    {
        int prog;

        try {
            if(so_codigo == 1)
                prog = new ProcessBuilder("cmd.exe","/c","start", url).inheritIO().start().waitFor();
            else
                prog = new ProcessBuilder("/usr/bin/xdg-open", url).inheritIO().start().waitFor();

            System.out.println("Status="+prog);

        } catch (IOException | InterruptedException ex) {
            System.out.println("ERROR: No se pudo abrir el navegador.");
            System.err.println(ex.getMessage());
        }

        leaTecla('r');
        System.out.println("Regresando a menu principal...");
    }

    public void MenuPrincipal()
    {
        System.out.print(Color.BlancoIntensoSobreVerde());
        System.out.println("\t    << Menú principal >>    \t");
        System.out.print(Color.AtributosNormales());

        System.out.println();

        System.out.println("\t[1] Tabla de conversión Decimal -- Binario");
        System.out.println("\t[2] Convertir Decimal -- Binario");
        System.out.println("\t[3] Convertir Binario -- Decimal");
        System.out.println("\t[4] Cálculos aritméticos");
        System.out.println("\t[5] Calculadora");
        System.out.println("\t[6] Aprende el sistema binario en Internet");
        System.out.println("\t[7] Unidades de medida de almacenamiento de datos");
        System.out.println("\t[8] Laboratorio de prácticas");

        System.out.println("\t[9] Salir.");
    }

    public void ejecutar()
    {
        beep();
        cls();

        System.out.print(Color.BlancoIntensoSobreVerde());
        System.out.println(tituloPrincipal);
	System.out.print(Color.AtributosNormales());

        System.out.println();

        MenuPrincipal();

        while (!salir) {
            try {
                opcion = (char) System.in.read();
            } catch (IOException ex) {
                System.getLogger(NumeracionBinaria.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
            }

            switch (opcion) {
                case '\r':
                case '\n':
                        break;

                case '1':    // opcion 1
                        TablaConversion();
                        cls();
                        MenuPrincipal();
                        break;

                case '2':   // opcion 2
                        Decimal_Binario();
                        cls();
                        MenuPrincipal();
                        break;

                case '3':   // opcion 3
                        Binario_Decimal();
                        cls();
                        MenuPrincipal();
                        break;

                case '4':   // opcion 4
                        operarCalculos();
                        cls();
                        MenuPrincipal();
                        break;

                case '5':   // opcion 5
                        abrirCalculadora();
                        cls();
                        MenuPrincipal();
                        break;

                case '6':   // opcion 6
                        abrirNavegador("https://www.areatecnologia.com/sistema-binario.htm");
                        cls();
                        MenuPrincipal();
                        break;

                case '7':   // opcion 7
                        abrirNavegador("./doc/TablaPotencias2.html");
                        cls();
                        MenuPrincipal();
                        break;

                case '8':   // opcion 8
                        abrirNavegador("./doc/Ejercicios.html");
                        cls();
                        MenuPrincipal();
                        break;

                case '9':   // opcion salir
                        System.out.println("Opcion salir");
                        salir = true;
                        break;

                default:    // opcion erronea
                        System.out.println("Opcion incorrecta.");

            }  // fin switch()
        }  // fin while()
    }

    // Entrada principal al programa 'NumeracionBinaria.jar'
    public static void main(String[] args)
    {
        int mensaje_info = JOptionPane.INFORMATION_MESSAGE;
        int argumentos = args.length;
        String titulo = "Sistema de numeración binaria";
        String mensaje = "¡Bienvenido a la aplicación NumeracionBinaria!\n¿Listo para aprender?";
        NumeracionBinaria programa = new NumeracionBinaria();

        if(argumentos == 0)
        {
            JOptionPane.showMessageDialog(null, mensaje, titulo, mensaje_info);
            programa.ejecutar();

            System.out.print(Color.NegroSobreVerde());
            System.out.println("Finalizado.");
            System.out.print(Color.AtributosNormales());
        }
        else
        {
	    // para añadir argumento: -licencia, -tui, ...
	    // es el argumento -version?
            if (args[0].equals("-version")) {
               String texto_version;
               String esteArchivo;
               String jarTrayectoria;
               File jarArchivo;

               jarTrayectoria = NumeracionBinaria.class.getProtectionDomain().getCodeSource().getLocation().getPath();
               jarArchivo = new File(jarTrayectoria);
               esteArchivo = "("+ jarArchivo.getName() + ")";

               texto_version = "NumeracionBinaria "+ esteArchivo + " 1.6.2026 20260610 (Oracle Linux Server 7.9)\n"+
			       "Copyright (C) 2026 Eugenio Mart\u00ednez.\n"+
			       "Esto es software libre; vea el c\u00f3digo para las condiciones de copia. NO hay\n"+
			       "garant\u00eda; ni siquiera para MERCANTIBILIDAD o IDONEIDAD PARA UN PROP\u00d3SITO EN\n"+
			       "PARTICULAR.";

                System.out.print("Versión del producto\nNumeracionBinaria ");
                System.out.println("corriendo en " + programa.nombreSistemaOp());

                System.out.println(texto_version);
            }
            else
            {
                System.out.println("ERROR: argumento no reconocido.\nUtilice los siguientes argumentos reconocidos:");
                System.out.println("\t-version  <> muestra la info. sobre esta aplicación.");
            }
        }
    }  // --fin main()--
}
// __________::__________
/*
NumeracionBinaria (NumeracionBinaria.jar) 1.6.2026 20260610 (Oracle Linux Server 7.9)
Copyright (C) 2026 Eugenio Martínez.
Esto es software libre; vea el código para las condiciones de copia. NO hay
garantía; ni siquiera para MERCANTIBILIDAD o IDONEIDAD PARA UN PROPÓSITO EN
PARTICULAR.
*/
