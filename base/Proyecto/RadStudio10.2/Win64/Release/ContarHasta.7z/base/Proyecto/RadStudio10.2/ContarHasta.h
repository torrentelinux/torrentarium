// ContarHasta.h
// Octulio Bilet�n - torrentelinux@gmail.com - 04|2019
// Realizar la cuenta desde 0 hasta 2^N - 1
// Proyecto ContarHasta.cbproj para Embarcadero RAD Studio 10.2/RAD Studio 2010

#ifdef _WIN32
#include <tchar.h>
#else
  typedef char _TCHAR;
  #define _tmain main
#endif

#include <windows.h>
#include <sstream>

#include "LadrilloModular.h"

void Entry(void);
void Exit(void);

#pragma startup Entry
#pragma exit Exit

