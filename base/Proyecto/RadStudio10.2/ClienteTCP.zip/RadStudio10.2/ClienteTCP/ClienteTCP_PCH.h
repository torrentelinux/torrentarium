// Encabezamiento
#include <vcl.h>
#include <tchar.h>

