// Encabezamiento
#include <tchar.h>
#include <vcl.h>
