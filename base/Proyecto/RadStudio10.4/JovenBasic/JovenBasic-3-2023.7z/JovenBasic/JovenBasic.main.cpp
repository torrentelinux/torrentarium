// JovenBasic.main.cpp
// Define la funci�n main() para la biblioteca de clases 'JovenBasic'
//
// Licencia : Copyright �Octulio Bilet�n, 2018-2023
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

#include <JovenBasic.h>

void VentanaVCL(void);
void VentanaConsola(void);

USEFORM("Pform1.cpp", frmDibujo);
bool VCLPreparado = false;

#pragma argsused
int _tmain(int argc, _TCHAR* argv[])
{
   try
   {
	VentanaConsola();
	VentanaVCL();

	Application->Run();
   }
   catch(Exception &exception)
   {
	Application->ShowException(&exception);
   }

   catch(...)
   {
	try
	{
		throw Exception("");
	}
	catch(Exception &exception)
	{
		Application->ShowException(&exception);
	}
   }

   // Retorna al S.O.
   return Program.End();
}

// Prepara la ventana consola para ser visualizada en forma maximizada.
void VentanaConsola(void)
{
	COORD dim_pantalla = { 132, 42 };
	SMALL_RECT tam_ventana = { 0, 0, 131, 41};

   SetConsoleTitle("Ventana Consola de Texto");

   SetConsoleScreenBufferSize(GetStdHandle(STD_OUTPUT_HANDLE), dim_pantalla);
   SetConsoleWindowInfo(GetStdHandle(STD_OUTPUT_HANDLE), TRUE, &tam_ventana);
   ShowWindow(GetConsoleWindow(), SW_SHOWMAXIMIZED);
}

// Prepara y crea la ventana de gr�ficos.
void VentanaVCL(void)
{
   if(VCLPreparado == false)
   {
     Application->Initialize();
     Application->MainFormOnTaskBar = true;
     Application->CreateForm(__classid(TfrmDibujo), &frmDibujo);

     VCLPreparado = true;
   }
}

