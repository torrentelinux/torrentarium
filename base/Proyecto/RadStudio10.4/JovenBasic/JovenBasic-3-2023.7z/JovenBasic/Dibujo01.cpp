// Dibujo01.cpp

#include <JovenBasic.h>

void JovenBasic::Run()
{
   TextWindow.Print("Programa iniciado...");
}

void JovenBasic::DrawGraphicsWindow()
{
   GraphicsWindow.Title = "Dibujo 01";
   GraphicsWindow.ShowMaximized();
   GraphicsWindow.ShowBorder(false);

   GraphicsWindow.BackgroundColor = "Black";
   GraphicsWindow.BrushColor = "Black";
   GraphicsWindow.BrushStyle = "Clear";

   GraphicsWindow.FontColor = "White";
   GraphicsWindow.FontBkColor = "Lime";
   GraphicsWindow.FontName = "Batang";
   GraphicsWindow.FontSize = 16;
   GraphicsWindow.Clear();

   GraphicsWindow.DrawText(10, 10, "Hola...");

   GraphicsWindow.PenColor = "Blue";
   GraphicsWindow.DrawEllipse(10,10,200,100);

   GraphicsWindow.PenColor = "Red";
   GraphicsWindow.DrawRectangle(20, 20, 300, 60);

   GraphicsWindow.PenColor = "White";
   GraphicsWindow.Circle(220, 230, 200);

   Program.Notice();
}
