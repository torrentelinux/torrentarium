//---------------------------------------------------------------------------
// Encabezado : JovenBasic.h
// Autor      : Octulio Bilet�n - torrentelinux@gmail.com
// Prop�sito  : Biblioteca de clases para programar al estilo Small Basic de Microsoft
//              o tambi�n a la manera cl�sica del lenguaje Basic.
// Fecha      : Ultima modificaci�n domingo, 05 de Marzo de 2023.
// Licencia   : Copyright �Octulio Bilet�n, 2018-2023
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

//---------------------------------------------------------------------------
// Esto es BASIC con clases en C++.
//---------------------------------------------------------------------------
#include <wchar.h>
#include <vcl.h>
#include <windows.h>

class CTextWindow
{
   private:
	String str_buffer;

   public:
	CTextWindow();

	// BASIC estilo cl�sico.
	void Input(int &dat);
	void InputPrompt(char *s, int &i);
	void Clear(void);
	void Print();
	void Print(char *m);
	void Print(char m);
	void Print(wchar_t *m);
	void Print(wchar_t m);

	// Small Basic estilo Microsoft.
	void Cls(void);
	String Read(void);
	void WriteLine(int i);
	void WriteLine(long double ld);
	void WriteLine(char *m);
	void WriteLine(wchar_t *m);
};

class CGraphicsWindow
{
   private:
   	TColor fbcolor;
        TBrushStyle bs;

        TColor getColor(String c);
        TBrushStyle getBrush(String b);

   public:
	String BackgroundColor;
        String BrushColor;
        String BrushStyle;
        String PenColor;
        int    PenWidth;
	String FontName;
        String FontBold;
        int    FontSize;
        String FontColor;
        String FontBkColor;
        String Title;

	CGraphicsWindow();

	void SetPixel(int x, int y, char *c);
	void SetPixel(int x, int y, TColor c);
	void Circle(int x, int y, int r);
        void DrawEllipse(int x, int y, int w, int h);
	void DrawRectangle(int x, int y, int w, int h);
	void FillRectangle(int x, int y, int w, int h);
	void DrawText(int x, int y, String s);
        void Beep();
        void Clear();
	void Show();
        void Hide();
        void ShowNormal();
        void ShowMaximized();
        void ShowMinimized();
        void ShowBorder(bool flag);
};

class CDesktop
{
   private:
   	int dsk_status;

   public:
   	CDesktop();
	~CDesktop();

	void SetWallPaper(String s);
};

class CMath
{
   public:
   	CMath();
	int GetRandomNumber(int n);
};

class CMem
{
   public:
   	void Poke(int m, _TCHAR d);
        _TCHAR Peek(int m);
};

class CProgram
{
    public:
    	CMem Mem;

	int  End(void);
	int  Shell(const char *cmd);
	void EndProgram(void);
	void Finish(void);
        void Notice();
};

class JovenBasic
{
   private:
	int opt_base;
	
   public:
	JovenBasic();
	void OptionBase(unsigned short int ob);
	int status();

	// El usuario debe definir �sta funci�n miembro.
	// Es el punto de entrada al "programa Basic".
	void Run();

	// El usuario debe definir �sta funci�n miembro.
	// Es el punto de entrada para la visualizaci�n
        // de los gr�ficos en la ventana frmDibujo.
        void DrawGraphicsWindow();
};

// Las instancias globales de las clases de JovenBasic
extern CTextWindow TextWindow;
extern CGraphicsWindow GraphicsWindow;
extern CDesktop Desktop;
extern CMath Math;
extern CProgram Program;
extern JovenBasic Basic;
