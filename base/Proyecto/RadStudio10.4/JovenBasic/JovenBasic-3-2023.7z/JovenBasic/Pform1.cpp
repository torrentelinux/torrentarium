// Pform1.cpp
// Octulio Bilet�n - torrentelinux@gmail.com - Marzo de 2023
// Este m�dulo crea una ventana para gr�ficos usando 'VCL'
// de Embarcadero RAD Studio.
// Este m�dulo, de 32 bits, es compatible con Embarcadero RAD Studio XE4
// y versiones posteriores.

//---------------------------------------------------------------------------
#include <vcl.h>
#include <JovenBasic.h>
#pragma hdrstop

#include "Pform1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

JovenBasic Basic;
TfrmDibujo *frmDibujo;
void __fastcall TfrmDibujo::MiEvento(TObject *Sender, bool &Done)
{
   if(Accionar)
   {
     Basic.Run();
     Accionar = false;
   }
}
//---------------------------------------------------------------------------
__fastcall TfrmDibujo::TfrmDibujo(TComponent* Owner)
	: TForm(Owner)
{
   Application->OnIdle = MiEvento;
   Accionar = true;
}
//---------------------------------------------------------------------------
// Cierra la ventana VCL
void __fastcall TfrmDibujo::FormClose(TObject *Sender, TCloseAction &Action)
{
   Hide();
}
//---------------------------------------------------------------------------
// Destruye la ventana VCL
void __fastcall TfrmDibujo::FormDestroy(TObject *Sender)
{
   // Destruye el formulario y libera la memoria utilizada
   Release();
}
//---------------------------------------------------------------------------
// Dibuja todos los elementos gr�ficos en la ventana VCL
void __fastcall TfrmDibujo::FormPaint(TObject *Sender)
{
   btnCerrar->Hide();  // Oculta el bot�n Cerrar mientras se dibuja la ventana VCL...
   Basic.DrawGraphicsWindow();  // Muestra los gr�ficos definidos por el usuario...
}
//---------------------------------------------------------------------------
void __fastcall TfrmDibujo::FormClick(TObject *Sender)
{
   MostrarBtnCerrar();
}
//---------------------------------------------------------------------------
void __fastcall TfrmDibujo::FormKeyPress(TObject *Sender, wchar_t &Key)
{
   // Tecla 'ESC' o 'Intro' muestra bot�n cerrar en pantalla.
   if(Key == VK_ESCAPE or Key == VK_RETURN)
     MostrarBtnCerrar();
}
//---------------------------------------------------------------------------
void __fastcall TfrmDibujo::FormResize(TObject *Sender)
{
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TfrmDibujo::btnCerrarClick(TObject *Sender)
{
   Close();
}
//---------------------------------------------------------------------------
void TfrmDibujo::MostrarBtnCerrar()
{
   btnCerrar->Left = Width - btnCerrar->Width - 18;
   btnCerrar->Top  = Height - btnCerrar->Height - 38;

   // Muestra el bot�n Cerrar cuando se hace clic en la superficie de la ventana VCL...
   btnCerrar->Show();
   btnCerrar->SetFocus();
}
//---------------------------------------------------------------------------

