// Pform1.h
// Octulio Bilet�n - torrentelinux@gmail.com - Marzo de 2023
//---------------------------------------------------------------------------

#ifndef Pform1H
#define Pform1H
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
//---------------------------------------------------------------------------
class TfrmDibujo : public TForm
{
__published:	// IDE-managed Components
	TButton *btnCerrar;
	void __fastcall FormPaint(TObject *Sender);
	void __fastcall FormDestroy(TObject *Sender);
	void __fastcall btnCerrarClick(TObject *Sender);
	void __fastcall FormClick(TObject *Sender);
	void __fastcall FormKeyPress(TObject *Sender, wchar_t &Key);
	void __fastcall FormResize(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
   private:	// User declarations
	bool Accionar;
	void MostrarBtnCerrar();
	void __fastcall MiEvento(TObject *Sender, bool &Done);
   protected:
   public:	// User declarations
	__fastcall TfrmDibujo(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmDibujo *frmDibujo;
//---------------------------------------------------------------------------
#endif
