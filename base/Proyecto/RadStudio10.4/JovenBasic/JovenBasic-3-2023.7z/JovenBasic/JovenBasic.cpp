//---------------------------------------------------------------------------
// M�dulo   : JovenBasic.cpp
// Autor    : Octulio Bilet�n - torrentelinux@gmail.com
// Prop�sito: Definir una biblioteca de clases en C++ para programar al estilo
//            Small Basic de Microsoft o tambi�n a la manera cl�sica
//            del lenguaje Basic.
// Fecha    : Ultima modificaci�n domingo, 05 de marzo de 2023.
// Licencia : Copyright �Octulio Bilet�n, 2018-2023.
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

//___________________________________________________________________________//
// Esto es BASIC con clases en C++.                                          //
//���������������������������������������������������������������������������//

#include <wchar.h>
#include <vcl.h>
#include <windows.h>
#include <iostream>
#include <iomanip>
#include <stdlib>
#include <cerrno>
#include <conio.h>
#pragma hdrstop

#include <twlib.h>
#include <_JovenBasic.h>
#include "Pform1.h"

using namespace std;
extern bool VCLPreparado;

// C�digo de salida al S.O.
static jb_status = 0;

JovenBasic::JovenBasic()
{
   // Inicializa Option Base a 0.
   opt_base = 0;

   wcout << TxtAnsi2TxtOem("JovenBasic ver. 1.0.5 - � Octulio Bilet�n, March 2023.") << endl;
   wcout << L"Ready" << endl << flush;
}

// OptionBase() determina cu�l es el 1er. elemento de un arreglo de datos: 0 o 1.
// Referencia: http://robhagemans.github.io/pcbasic/doc/#OPTION-BASE
void JovenBasic::OptionBase(unsigned short int ob)
{
   if(ob < 2)
     opt_base = ob;     // Inicializa Option Base a 'ob'
}

int JovenBasic::status()
{
    return jb_status;
}

// Clase CTextWindow - definiciones de sus funciones miembros -

CTextWindow::CTextWindow()
{
   _setcursortype(_SOLIDCURSOR);
}

// Limpia toda la pantalla de texto
void CTextWindow::Clear(void)
{
   clrscr();
}

// Limpia toda la pantalla de texto
void CTextWindow::Cls(void)
{
   clrscr();
}

void CTextWindow::Input(int &dat)
{
   cout << "? ";
   cin >> dat;
}

// Muestra un mensaje de texto y a continuaci�n espera el ingreso por teclado
// de un valor num�rico tipo entero.
void CTextWindow::InputPrompt(char *s, int &i)
{
   cout << TxtAnsi2TxtOem(s) << "? " << flush;
   cin >> i;
}

void CTextWindow::Print()
{
   cout << endl << flush;
}

void CTextWindow::Print(char *m)
{
   cout << TxtAnsi2TxtOem(m) << endl << flush;
}

void CTextWindow::Print(wchar_t *m)
{
   wcout << m << endl << flush;
}

void CTextWindow::Print(char m)
{
   cout << m << endl << flush;
}

void CTextWindow::Print(wchar_t m)
{
   wcout << m << endl << flush;
}

String CTextWindow::Read(void)
{
	char m[160];

   cin >> m;
   str_buffer = m;
   
   return str_buffer;
}

void CTextWindow::WriteLine(int i)
{
   cout << i << endl << flush;
}

void CTextWindow::WriteLine(long double ld)
{
   int anterior = cout.precision();

   cout.setf(ios_base::fixed, ios_base::floatfield);
   cout.precision(29);
   cout << ld << endl << flush;

   cout.precision(anterior);
}

void CTextWindow::WriteLine(char *m)
{
   cout << TxtAnsi2TxtOem(m) << endl << flush;
}

void CTextWindow::WriteLine(wchar_t *m)
{
   wcout << m << endl << flush;
}

// Clase CGraphicsWindow - definiciones de sus funciones miembros -

CGraphicsWindow::CGraphicsWindow()
{
   if(VCLPreparado == false)
   {
     // Inicializa la ventana de dibujos.
     Application->Initialize();
     Application->MainFormOnTaskBar = true;
     Application->CreateForm(__classid(TfrmDibujo), &frmDibujo);

     VCLPreparado = true;
   }

   // Color de fondo de la ventana
   BackgroundColor = "White";
   frmDibujo->Color = getColor(BackgroundColor);

   // Color de la brocha para pintar objetos geom�tricos
   BrushColor = "SlateBlue";
   frmDibujo->Canvas->Brush->Color = getColor(BrushColor);

   // Estilo de la brocha
   BrushStyle = "Solid";
   frmDibujo->Canvas->Brush->Style = getBrush(BrushStyle);

   // Color del l�piz
   PenColor = "Black";
   frmDibujo->Canvas->Pen->Color = getColor(PenColor);

   // Grosor del l�piz
   PenWidth = 2;
   frmDibujo->Canvas->Pen->Width = PenWidth;

   // Nombre del tipo de letra
   FontName = "Tahoma";
   frmDibujo->Canvas->Font->Name = FontName;

   // Texto en negrita habilitado
   FontBold = "True";
   frmDibujo->Canvas->Font->Style = TFontStyles() << fsBold;

   // Tama�o del tipo de letra
   FontSize = 12;
   frmDibujo->Canvas->Font->Size = FontSize;

   // Color del texto: frente y fondo
   FontColor = "Black";
   frmDibujo->Canvas->Font->Color = getColor(FontColor);

   FontBkColor = BackgroundColor;
   fbcolor = getColor(FontBkColor);

   // T�tulo de la ventana
   Title = "";
   frmDibujo->Caption = Title;
}

// Hace visible la ventana
void CGraphicsWindow::Show()
{
   frmDibujo->Caption = Title;
   frmDibujo->Show();
}

// Oculta la ventana
void CGraphicsWindow::Hide()
{
   frmDibujo->Hide();
}

void CGraphicsWindow::Clear()
{
   // Coloca el t�tulo a la ventana de dibujo
   frmDibujo->Caption = Title;

   // Color del fondo de la ventana
   frmDibujo->Color = getColor(BackgroundColor);

   // Color y estilo de la brocha
   frmDibujo->Canvas->Brush->Color = getColor(BrushColor);
   frmDibujo->Canvas->Brush->Style = getBrush(BrushStyle);

   // Color del l�piz
   frmDibujo->Canvas->Pen->Color = getColor(PenColor);

   // Grosor del l�piz
   frmDibujo->Canvas->Pen->Width = PenWidth;

   // Color de la tipograf�a
   frmDibujo->Canvas->Font->Color = getColor(FontColor);
   fbcolor = getColor(FontBkColor);

   // Modifica el tama�o de las letras/s�mbolos
   frmDibujo->Canvas->Font->Size = FontSize;
   frmDibujo->Canvas->Font->Name = FontName;
}

// Devuelve el valor num�rico TBrushStyle que corresponde a 'b' estilo de la brocha
TBrushStyle CGraphicsWindow::getBrush(String b)
{
	TBrushStyle id_brocha = bsClear;

   if(b.Compare("Solid") == 0)
     id_brocha = bsSolid;

   if(b.Compare("Clear") == 0)
     id_brocha = bsClear;

   if(b.Compare("Horizontal") == 0)
     id_brocha = bsHorizontal;

   if(b.Compare("Vertical") == 0)
     id_brocha = bsVertical;

   return id_brocha;
}

// Devuelve el valor num�rico TColor que corresponde a 'c' color
TColor CGraphicsWindow::getColor(String c)
{
	TColor id_color = (TColor)clSystemColor;

   if(c.Compare("Black") == 0)
     id_color = clBlack;

   if(c.Compare("White") == 0)
     id_color = clWhite;

   if(c.Compare("Red") == 0)
     id_color = clRed;

   if(c.Compare("Blue") == 0)
     id_color = clBlue;

   if(c.Compare("Green") == 0)
     id_color = clGreen;

   if(c.Compare("LightGreen") == 0)
     id_color = (TColor)clWebLightGreen;

   if(c.Compare("Lime") == 0)
     id_color = (TColor)clWebLimeGreen;

   if(c.Compare("SlateBlue") == 0)
     id_color = (TColor)clWebSlateBlue;

   if(c.IsEmpty())
     id_color = clBlack;

   return id_color;
}

void CGraphicsWindow::SetPixel(int x, int y, char *c)
{
   SetPixel(x, y, getColor(c));
}

// Dibuja un punto con color 'c' en la posici�n 'x,y'
void CGraphicsWindow::SetPixel(int x, int y, TColor c)
{
   ::SetPixel(frmDibujo->Canvas->Handle, x, y, c);
}

// Dibuja un c�rculo con centro 'x,y' y radio 'r'
void CGraphicsWindow::Circle(int x, int y, int r)
{
	TBrushStyle tmp0 = frmDibujo->Canvas->Brush->Style;
	TColor tmp1 = frmDibujo->Canvas->Brush->Color;
	TColor tmp2 = frmDibujo->Canvas->Pen->Color;

   frmDibujo->Canvas->Brush->Color = getColor(BrushColor);
   frmDibujo->Canvas->Brush->Style = getBrush(BrushStyle);
   frmDibujo->Canvas->Pen->Color = getColor(PenColor);

   frmDibujo->Canvas->Ellipse(x - r, y - r, x + r, y + r);

   frmDibujo->Canvas->Brush->Style = tmp0;
   frmDibujo->Canvas->Brush->Color = tmp1;
   frmDibujo->Canvas->Pen->Color = tmp2;
}

void CGraphicsWindow::DrawEllipse(int x, int y, int w, int h)
{
	TBrushStyle tmp0 = frmDibujo->Canvas->Brush->Style;
	TColor tmp1 = frmDibujo->Canvas->Brush->Color;
	TColor tmp2 = frmDibujo->Canvas->Pen->Color;

   frmDibujo->Canvas->Brush->Color = getColor(BrushColor);
   frmDibujo->Canvas->Brush->Style = getBrush(BrushStyle);
   frmDibujo->Canvas->Pen->Color   = getColor(PenColor);

   frmDibujo->Canvas->Ellipse(x, y, w, h);

   frmDibujo->Canvas->Brush->Style = tmp0;
   frmDibujo->Canvas->Brush->Color = tmp1;
   frmDibujo->Canvas->Pen->Color   = tmp2;
}

void CGraphicsWindow::DrawRectangle(int x, int y, int w, int h)
{
	TColor tmp = frmDibujo->Canvas->Brush->Color;
	TRect reg = Rect(x, y, w, h);

   frmDibujo->Canvas->Brush->Color = getColor(PenColor);
   frmDibujo->Canvas->FrameRect(reg);
   frmDibujo->Canvas->Brush->Color = tmp;
}

void CGraphicsWindow::FillRectangle(int x, int y, int w, int h)
{
	// FALTA COMPLETAR !!!
}

void CGraphicsWindow::DrawText(int x, int y, String s)
{
	TColor tmp = frmDibujo->Canvas->Brush->Color;
	TRect area = Rect(x, y, x + frmDibujo->Canvas->TextWidth(s) + frmDibujo->Font->Size,
				frmDibujo->Canvas->TextHeight(s) + abs(frmDibujo->Font->Height));

   frmDibujo->Canvas->Brush->Color = fbcolor;

   frmDibujo->Canvas->FillRect(area);
   frmDibujo->Canvas->TextRect(area, x, y, s);

   frmDibujo->Canvas->Brush->Color = tmp;
}

// Emite un pitido por el altavoz de la PC de 800 Hz durante 250 milisegs.
void CGraphicsWindow::Beep()
{
   ::Beep(800, 250);
}

void CGraphicsWindow::ShowNormal()
{
   frmDibujo->WindowState = wsNormal;
}

void CGraphicsWindow::ShowMaximized()
{
   frmDibujo->WindowState = wsMaximized;
}

void CGraphicsWindow::ShowMinimized()
{
   frmDibujo->WindowState = wsMinimized;
}

void CGraphicsWindow::ShowBorder(bool flag)
{
   if(flag)
     frmDibujo->BorderStyle = bsSizeable;
   else
     frmDibujo->BorderStyle = bsNone;
}

// Clase CMath - definiciones de sus funciones miembros -

CMath::CMath()
{
}

int CMath::GetRandomNumber(int n)
{
   return Random(n);
}

// Clase CMem - definiciones de sus funciones miembros -

CMem::CMem()
{

}

CMem::~CMem()
{

}

void CMem::Poke(int m, _TCHAR d)
{

}

_TCHAR CMem::Peek(int m)
{
   return NULL;
}

// Clase CProgram - definiciones de sus funciones miembros -

void CProgram::EndProgram(void)
{
   cout << "Ok" << endl << flush;
   PressEnter();

   jb_status = 0;
}

int CProgram::End(void)
{
   cout << "Press Enter key to end..." << endl << flush;
   PressEnter();

   return jb_status;
}

void CProgram::Finish(void)
{
   cout << "Press Enter key to finish..." << endl << flush;
   PressEnter();

   exit(0);
}

int CProgram::Shell(const char *cmd)
{
	int sh_status;

   errno = 0;
   sh_status = system(cmd);

   if(sh_status < 0)
     sh_status = errno;

   return sh_status;
}

// Muestra un texto informativo centrado al pie de la pantalla
// informando al usuario que debe presionar tecla ESC/Intro para
// continuar y una vez presionada dicha tecla, 'frmDibujo' muestra
// el bot�n 'Cerrar'.
void CProgram::Notice()
{
     	int x, y;
        size_t ltext;
	TColor      tmp1 = Application->MainForm->Canvas->Font->Color;
        TBrushStyle tmp2 = Application->MainForm->Canvas->Brush->Style;
	wchar_t msj[] = L"Press ESC or Return key to continue...";

   ltext = (wcslen(msj) * Application->MainForm->Canvas->Font->Size) / 3;
   x = (Application->MainForm->Width / 2) - ltext;
   y = Application->MainForm->Height - Application->MainForm->Canvas->TextHeight(msj) - 37;

   Application->MainForm->Canvas->Font->Color = (TColor) (clWhite xor ::GetPixel(frmDibujo->Canvas->Handle, x, y));
   Application->MainForm->Canvas->Brush->Style = bsClear;

   Application->MainForm->Canvas->TextOut(x, y, msj);

   Application->MainForm->Canvas->Brush->Style = tmp2;
   Application->MainForm->Canvas->Font->Color =  tmp1;
}

// Clase CDesktop - definiciones de sus funciones miembros -

CDesktop::CDesktop()
{
   dsk_status = 0;

    // 1. Initialize the COM library (make Windows load the DLLs).
    // Normally you would call this in your InitInstance() or other startup code.
    // Init the COM library - have Windows load up the DLLs.
   if(FAILED(CoInitialize(NULL)))
   {
     dsk_status = -1;
   }
}

void CDesktop::SetWallPaper(String s)
{
	HRESULT hr = NULL;
	IActiveDesktop* pIAD = NULL;

   // 2. Create a COM object, using the Active Desktop coclass provided by the shell.
   // The 4th parameter tells COM what interface we want (IActiveDesktop).
   hr = CoCreateInstance(CLSID_ActiveDesktop, NULL, CLSCTX_INPROC_SERVER,
                          IID_IActiveDesktop, (void **)&pIAD);

   if(SUCCEEDED(hr))
   {
     // 3. If the COM object was created, call its SetWallpaper() method.
     hr = pIAD->SetWallpaper( s.c_str(), 0);
     hr = pIAD->ApplyChanges(AD_APPLY_ALL);

     if(SUCCEEDED(hr))
     {
	 // 4. If SetWallpaper() succeeded, OK.
	 dsk_status = 1;
     }
     else
     {
	 dsk_status = -2;
     }

     // 5. Release the interface.
     pIAD->Release();
   }
   else
   {
      dsk_status = -3;
   }

   if(dsk_status < 0)
   {
     Application->MessageBox(L"No se pudo cambiar el papel tapiz del escritorio.", L"Error", MB_OK|MB_ICONERROR);
   }
}

CDesktop::~CDesktop()
{
    // 6. Uninit the COM library.
    CoUninitialize();
    dsk_status = 0;
}

// Defino las instancias globales de las clases de JovenBasic
CTextWindow TextWindow;
CGraphicsWindow GraphicsWindow;
CDesktop Desktop;
CMath Math;
CProgram Program;
// ---------------------------------------------------------------------------

