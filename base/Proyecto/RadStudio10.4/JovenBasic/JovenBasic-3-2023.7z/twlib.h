/* twlib.h
 * Autor: Octulio Bilet�n - torrentelinux@gmail.com
 * Fecha Creaci�n: 13-Nov-2014
   TorrenteWindowsLibrary: twlib.dll
   Versi�n compatible con CodeGear C++ Builder 2007,
   Embarcadero RadStudio XE4 y 10.2 Tokyo.
*/

#if !defined(__TWLIB_ob1)
#define __TWLIB_ob1

#include <time.h>

#ifdef  __cplusplus
extern "C" {
#endif

typedef char          * ptchar_t;
typedef const char    * cptchar_t;
typedef wchar_t       * wptchar_t;
typedef const wchar_t * wcptchar_t;

/* -- Versi�n ANSI -- */
__declspec(dllimport) ptchar_t form(ptchar_t format, ...);

/* Hace una pausa hasta que se presiona la tecla Intro/Enter. */
__declspec(dllimport) void     PressEnter(void);

/* Convierte una secuencia de caracteres ANSI a una OEM.
   Devuelve la secuencia de caracteres convertidas a OEM.
   Devuelve NULL en caso de error.
*/
__declspec(dllimport) ptchar_t TxtAnsi2TxtOem(cptchar_t texto_ansi);

__declspec(dllimport) int DataInput(ptchar_t msg, ptchar_t format, ...);

/* Calcula y devuelve la diferencia de tiempo entre t1 y t0. */
__declspec(dllimport) float diffclock(clock_t t1, clock_t t0);

/* -- Versi�n UNICODE -- */
__declspec(dllimport) wptchar_t wform(wptchar_t wformat, ...);
__declspec(dllimport) wptchar_t wTxtAnsi2TxtOem(wcptchar_t texto_ansi);

#ifdef __cplusplus
}    /* extern "C" */
#endif

#endif  /* __TWLIB_ob1 */
