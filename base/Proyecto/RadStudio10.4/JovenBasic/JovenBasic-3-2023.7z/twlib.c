/* M�dulo: twlib.c
 * Autor: Octulio Bilet�n - torrentelinux@gmail.com
 * Fecha Creaci�n: 13-Nov-2014
 * Descripci�n: TorrenteWindowsLibrary.
                Definiciones de las funciones:
                  form() y wform(),
                  PressEnter(),
                  TxtAnsi2TxtOem().
                Versi�n compatible con CodeGear C++ Builder 2007
                Embarcadero RadStudio XE4 y 10.2 Tokyo.
 * Licencia   : Copyright �Octulio Bilet�n, 2018
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

/*---------------------------------------------------------------------------*/
#define __CHEADER__
#define __CEFF__
#include <pragma.h>

#include <windows.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <time.h>
#include <io.h>
#include <mem.h>
#include <errno.h>
#include <wchar.h>
#pragma hdrstop
/*---------------------------------------------------------------------------*/

typedef char          * ptchar_t;
typedef const char    * cptchar_t;
typedef wchar_t       * wptchar_t;
typedef const wchar_t * wcptchar_t;

/* -- Versi�n ANSI -- */
__declspec(dllexport) ptchar_t form(ptchar_t format, ...);
__declspec(dllexport) void     PressEnter(void);
__declspec(dllexport) ptchar_t TxtAnsi2TxtOem(cptchar_t texto_ansi);
__declspec(dllexport) int      DataInput(ptchar_t msg, ptchar_t format, ...);
__declspec(dllexport) float    diffclock(clock_t t1, clock_t t0);

/* -- Versi�n UNICODE -- */
__declspec(dllexport) wptchar_t wform(wptchar_t wformat, ...);
__declspec(dllexport) wptchar_t wTxtAnsi2TxtOem(wcptchar_t texto_ansi);

/* Espacio de memoria para alojar el texto formateado */

/* -- Versi�n ANSI -- */
static char form_buffer[1024];

/* -- Versi�n UNICODE -- */
static wchar_t wform_buffer[1024];

#pragma argsused
int _libmain(unsigned long reason)
{
   return 1;
}

//---------------------------------------------------------------------------

/* Formatea los datos en una l�nea de textos */
/* Devuelve el texto formateado si hubo �xito sino NULL en caso fallido */
/* Actualiza la variable global del sistema errno: 0, EINVAL, ENOMEM */
/* -- Versi�n ANSI -- */
ptchar_t form(ptchar_t format, ...)
{
	int status = 0;
	va_list arg_ptr;

   errno = 0;  /* Limpia la variable de errores */

   if(format == NULL || *format == '\0')
   {
     errno = EINVAL;  /* Argumento inv�lido */
     return NULL;
   }

   memset(form_buffer, 0, 1024);

   va_start(arg_ptr, format);
   status = vsprintf(form_buffer, format, arg_ptr);
   va_end(arg_ptr);

   if(status == EOF)
   {
     errno = ENOMEM;  /* No hay suficiente memoria */
     return NULL;    /* Error al formatear los datos */
   }

   return form_buffer;  /* Devuelve el texto formateado */
}

/* Formatea los datos en una l�nea de textos */
/* Devuelve el texto formateado si hubo �xito sino NULL en caso fallido */
/* Actualiza la variable global del sistema errno: 0, EINVAL, ENOMEM */
/* -- Versi�n UNICODE -- */
wptchar_t wform(wptchar_t wformat, ...)
{
	int status = 0;
	va_list arg_ptr;

   errno = 0;  /* Limpia la variable de errores */

   if(wformat == NULL || *wformat == L'\0')
   {
     errno = EINVAL;  /* Argumento inv�lido */
     return NULL;
   }

   wmemset(wform_buffer, 0, 1024);

   va_start(arg_ptr, wformat);
   status = vswprintf(wform_buffer, wformat, arg_ptr);
   va_end(arg_ptr);

   if(status == WEOF)
   {
     errno = ENOMEM;  /* No hay suficiente memoria */
     return NULL;  /* Error al formatear los datos */
   }

   return wform_buffer;  /* Devuelve el texto formateado */
}

/* Hace una pausa hasta que se presiona la tecla Intro/Enter. */
void PressEnter(void)
{
	unsigned char tecla = 0;

   fflush(stdin);
   read(_fileno(stdin), &tecla, 1);
}

/* Versi�n ANSI
   Convierte una secuencia de caracteres ANSI a una OEM.
   Devuelve la secuencia de caracteres convertidas a OEM.
   Devuelve NULL en caso de error.
*/
ptchar_t TxtAnsi2TxtOem(cptchar_t texto_ansi)
{
	static char texto_oem[1040];

   if(texto_ansi == NULL)
     return NULL;

   if(strlen(texto_ansi) > 1023)
     return NULL;

   memset(texto_oem, 0, 1024);

   CharToOemA(texto_ansi, texto_oem);

   return texto_oem;
}

/* Versi�n UNICODE
   Convierte una secuencia de caracteres ANSI a una OEM.
   Devuelve la secuencia de caracteres convertidas a OEM.
   Devuelve NULL en caso de error.
*/
wptchar_t wTxtAnsi2TxtOem(wcptchar_t texto_ansi)
{
	static wchar_t texto_oem[1040];

   if(texto_ansi == NULL)
     return NULL;

   if(wcslen(texto_ansi) > 1023)
     return NULL;

   wmemset(texto_oem, 0, 1024);

   CharToOemW(texto_ansi, texto_oem);

   return texto_oem;
}

int DataInput(ptchar_t msg, ptchar_t format, ...)
{
	va_list argpt;
	int status = 0;
	int i = 0;

   errno = 0;

   while(msg[i])
     fputc(msg[i++], stdout);

   va_start(argpt, format);
   status = vscanf(format, argpt);
   va_end(argpt);

   return status;
}

// Calcula y devuelve la diferencia de tiempo entre t1 y t0.
float diffclock(clock_t t1, clock_t t0)
{
   return ((t1 - t0) / CLK_TCK);
}
