// Programa: CajaRegistradoraStraton.java
// Autor: Octulio Biletán - Julio de 2021
// Propósito: Implementar la caja registradora para un negocio de ventas de productos.
// Para IDE Oracle JDeveloper 12c y para IDE Apache NetBeans 12.4 (Windows 32/64 bits).
//
//---------Simulación de una caja registradora-------------------------------
//

package cajaregistradorastraton;

import java.awt.Toolkit;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import java.lang.management.ManagementFactory;

import java.nio.channels.FileLock;

import java.text.DateFormat;

import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

import javax.swing.JOptionPane;

class CRSUsuarios
{
    // Identificadores de los usuarios autorizados
    private final String id_usuarios[] = { "84163", "987456321", "74123698" };
    
    // Nombres de los usuarios autorizados
    private final String se_usuarios[] = { "administrador", "supervisor", "operador" };
    
    boolean id_buscar(String idusr)
    {        
        boolean encontrado = false;
        
        for(int i = 0; i < id_usuarios.length; i++)
        {    
          if(idusr.compareTo(id_usuarios[i]) == 0)
          {  
              encontrado = true; 
              break;
          }
        }

        return encontrado;
    }

    String se_buscar(String idusr)
    {        
        String encontrado = "desconocido";
        
        for(int i = 0; i < id_usuarios.length; i++)
        {    
          if(idusr.compareTo(id_usuarios[i]) == 0)
          {  
              encontrado = se_usuarios[i]; 
              break;
          }
        }

        return encontrado;
    }
}

/**
 * Clase principal
 * @author Octulio Biletán
 */
public class CajaRegistradoraStraton 
{
    private boolean existe_candado;
    private String nombre_candado;
    private CRSUsuarios usuarios;
    private FileOutputStream fichero_candado;
    private FileLock cerrojo;
    private File fcandado;
    private static CajaRegistradoraStraton la_caja;

    CajaRegistradoraStraton()
    {
	// El candado está cerrado
	existe_candado = false;

	fichero_candado = null;
        cerrojo = null;

        // Se ubica el fichero candado.lck en %TMP%
        nombre_candado = System.getenv("TMP")+"\\candado.lck";
        fcandado = new File(nombre_candado);

        usuarios = new CRSUsuarios();

        // Se elimina el fichero candado en caso de que existiese (¿corte de suministro eléctrico?)
        fcandado.delete();

        la_caja = this;
    }

    // Devuelve la instancia de esta clase
    public static CajaRegistradoraStraton miInstancia()
    {
        return la_caja;
    }

    // Devuelve true si está abierto el candado sino false
    boolean esta_abiertoCandado()
    {
	return existe_candado;
    }

    // Devuelve el nombre del usuario de acuerdo a su id de usuario
    String usuarioAcceso(String id_usr)
    {
        return usuarios.se_buscar(id_usr);
    }

    // Devuelve el ID del proceso en ejecución
    int idProceso()
    {
        //Alternativa: String pidnombre = ProcessHandle.current().toString(); 
        int pid = Integer.parseInt(ManagementFactory.getRuntimeMXBean().getName().substring(0,ManagementFactory.getRuntimeMXBean().getName().indexOf("@")));
        return pid;
    }

    void eliminarCandado()
    {
        try 
        {
            File candado;

            // Cierra candado
            cerrojo.channel().close();

            candado = new File(nombre_candado);

            // Va a borrar el fichero candado al salir de la Java VM
            candado.deleteOnExit();

	    // Da por cerrado el candado
            existe_candado = false;

        }
        catch(IOException ex) 
        {
            Logger.getLogger(CajaRegistradoraStraton.class.getName()).log(Level.SEVERE, "<< Error al eliminar candado >>", ex);
        }
    }

    void crearCandado()
    {
        try
        {
            // Se crea el fichero candado.lck
            fichero_candado = new FileOutputStream(nombre_candado);
            try
            {
                fichero_candado.write(1);
                fichero_candado.flush();

		// Pone candado -- activa --
                cerrojo = fichero_candado.getChannel().lock();

                // El candado está activado
                existe_candado = true;
            }
            catch(IOException ex) 
            {
                System.err.println("<< Error al crear candado >>");
                System.err.println(ex.getMessage());
            }
        }
        catch(FileNotFoundException ex) 
        {
            Logger.getLogger(CajaRegistradoraStraton.class.getName()).log(Level.SEVERE, "Error al acceder candado.", ex);
        }
    }

    // Reproduce una alarma audible tipo WAV-file
    void reproducirAlarma(String filename)
    {
        try
        {
            Clip fragmento = AudioSystem.getClip();
            
            fragmento.open(AudioSystem.getAudioInputStream(new File(filename)));
            fragmento.start();
        }
        catch(Exception ex)
        {
            ex.printStackTrace(System.out);
        }
    }

    // Activa una alarma audible mediante la reproducción de un fichero .wav
    void activarAlarma(String msj)
    {
        // Hace sonar un fichero de audio
        reproducirAlarma("sonido/register.wav");

	// Hace sonar el beep del sistema operativo
        Toolkit.getDefaultToolkit().beep();

	// Muestra un mensaje de aviso
        JOptionPane.showMessageDialog(null, msj, "Seguridad", JOptionPane.ERROR_MESSAGE);
    }

    // Solicita contraseña al usuario 'id_usr'
    // Devuelve true=aceptado - false=rechazado
    boolean claveAcceso(String id_usr)
    {
        boolean status;

        status = usuarios.id_buscar(id_usr);
        if(status == false)
          return status;  // Regresa por usuario no identificado

        status = true;  // Acceso autorizado.
        
        // Pide contraseña para verificar su autorización de acceso a la aplicación
        ClaveAcceso.arranque(id_usr);
        if(ClaveAcceso.codigo_salida() == 255)
            status = false;  // Acceso denegado.
        
        return status;
    }

    /**
     * Punto de entrada al paquete cajaregistradorastraton del programa CajaRegistradoraStraton.java<br>
     * Los únicos usuarios autorizados son: <b>Administrador</b>, <b>Supervisor</b> y <b>Operador</b>.<br><br>
     * <b>Ejemplo:</b> Abrir una ventana consola en el S.O. y ejecutar la siguiente línea<br>
     * C:\base\Proyecto\JDeveloper\CajaRegistradoraStraton\Cliente&gt;java -jar deploy\CajaRegistradoraStraton.jar 84163<br>
     * @param args :--: args[0]=id numérico del usuario autorizado.
     */
    public static void main(String[] args) 
    {
	boolean status = false;

        CajaRegistradoraStraton straton = new CajaRegistradoraStraton();
        straton.crearCandado();

	// ¿Está abierto el candado?
        if(straton.esta_abiertoCandado())
	{
          System.out.print("<< " + DateFormat.getDateTimeInstance().format(new Date()) + " pid " + straton.idProceso() + " >> Sesión abierta por ");

          if(args.length == 1)
          {
              // Unicos usuarios autorizados: administrador(id), supervisor(id), operador(id)
              System.out.println(straton.usuarioAcceso(args[0]));
              
              // Solicita 1ro. contraseña de acceso al usuario
              // Las claves se encuentran en el módulo ClaveAcceso.java
              status = straton.claveAcceso(args[0]);
              if(status == true)
                CajaPantalla.arranque(straton.usuarioAcceso(args[0]));
              else
              {
		    String mensaje = "Usuario no identificado.\nPóngase en contacto con su autoridad.\n";

                    // Hace sonar el beep del sistema operativo
                    Toolkit.getDefaultToolkit().beep();
		    System.err.println(mensaje + "Acceso denegado.");
              }
          }
          else
          {
              String mensaje = "Usted no tiene permiso por la autoridad competente para iniciar ésta aplicación.\nPóngase en contacto con su autoridad.";

              System.out.write(7); System.out.flush();
              System.out.println("usuario no autorizado.");

	      straton.activarAlarma(mensaje);
          }
	}
	// El candado está activado
        else
	{
	    String mensaje = "Esta aplicación ya se encuentra en ejecución.";

            System.err.println("La aplicación posee un candado activo.");
            straton.activarAlarma(mensaje);
	}
    }	// fin de main()
}
