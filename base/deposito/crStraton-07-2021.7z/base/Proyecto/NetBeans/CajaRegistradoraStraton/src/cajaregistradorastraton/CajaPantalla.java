// Módulo: CajaPantalla.java
// Autor: Octulio Biletán - Julio de 2021
// Propósito: Gestionar la E/S de productos y dinero de la caja registradora.
// Para IDE Oracle JDeveloper 12c y para IDE Apache NetBeans 12.4 (Windows 32/64 bits).
//
//---------Simulación de una caja registradora-------------------------------
//

package cajaregistradorastraton;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.io.*;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;
import javax.swing.JOptionPane;
import javax.swing.Timer;

/**
 *
 * @author Octulio Biletán
 */
public class CajaPantalla extends javax.swing.JFrame 
{
    Timer reloj;
    char[] fdatos;
    
// -----------------Los datos que contiene el fichero "datos/planillaCaja.txt"
    String codigo;
    String cantidad;
    String detalle;
    String precio;
// --------------------
    
    static int codigo_salida;
    
    /**
     * Crea un nuevo formulario CajaPantalla.
     * @param sesion
     */
    public CajaPantalla(String sesion) 
    {
        Font Verdana = new Font("Verdana", Font.BOLD, 14);
        codigo_salida = 0;
        fdatos = null;
        
        setLocale(Locale.FRENCH);        
        initComponents();
        inicializaReloj();
        
        lblSesion.setText(sesion);
        tblPlanilla.setShowGrid(true);
        tblPlanilla.setFont(Verdana);
        
        if(LeeFicheroDatos() == 0)
          PoneDatosPlanilla();
    }
    
    // Pone los datos leídos en la planilla
    public void PoneDatosPlanilla() 
    {
        int r, c;
        int pos_separador;
        int i;
        int li;
        int desde, hasta;
        String linea = "";

        r = 0; c = 0;
        
        // Recorre toda el área de datos
        for(li = 0; li < fdatos.length; li++) 
        {
          i = li;
          
          // Si encuentra un caracter nulo sale del ciclo for()
          if(fdatos[i] == '\0')
              break;
          
          // Ignora las líneas en blanco
          if(fdatos[i] > 0 && fdatos[i] < 33)  
            continue;
            
          // Lee cada línea de datos hasta llegar al salto de línea
          while(fdatos[i] != '\n')
            linea = linea + Character.toString(fdatos[i++]);
          
          // Marca el final de línea con ':'
          linea = linea + ':';
            
          desde = 0;
          hasta = linea.indexOf(':');
            
          // Extrae código y pone en planilla
          codigo = linea.substring(desde, hasta);
          tblPlanilla.setValueAt(Integer.valueOf(codigo), r, c++);
          
          desde = ++hasta;
          hasta = linea.indexOf(':', desde);

          // Extrae cantidad y pone en planilla
          cantidad = linea.substring(desde, hasta);
          tblPlanilla.setValueAt(Integer.valueOf(cantidad), r, c++);
            
          desde = ++hasta;
          hasta = linea.indexOf(':', desde);
          
          // Extrae detalle y pone en planilla
          detalle = linea.substring(desde, hasta);
          tblPlanilla.setValueAt(detalle, r, c++);
              
          desde = ++hasta;
          hasta = linea.indexOf(':', desde);
            
          // Extrae precio y pone en planilla
          precio = linea.substring(desde, --hasta);
          tblPlanilla.setValueAt(Float.valueOf(precio), r, c++);

          linea = "";
          r++; c = 0;
          li = i;    
        }
    }
    
    // Lee la planilla de datos desde un fichero de textos.
    // Devuelve 0 en caso de éxito sino 1 en caso de error.
    public int LeeFicheroDatos() 
    {
        int error_encontrado = 1;
        FileReader fichero;
        
        try 
        {
            fichero = new FileReader("datos/planillaCaja.txt");
        }
        catch(FileNotFoundException fex) 
        {
            JOptionPane.showMessageDialog(rootPane, "No se pudo abrir la planilla de datos.\n" + fex.getMessage());
            return error_encontrado;
        }

        // Lee los datos del fichero
        try 
        {
            fdatos = new char[4096];

            fichero.read(fdatos);
            fichero.close();
        }
        catch(IOException fex) 
        {
            JOptionPane.showMessageDialog(rootPane, "No se pudo leer la planilla de datos.\n" + fex.getMessage());
            return error_encontrado;
        }
        catch(OutOfMemoryError mex) 
        {
            // Compre más RAM !!
            JOptionPane.showMessageDialog(rootPane, "Insuficiente espacio de memoria.\n" + mex.getMessage());
            return error_encontrado;
        }
        
        error_encontrado = 0;
        return error_encontrado;
    }

    private void inicializaReloj()
    {        
        reloj = new Timer(1000, (ActionEvent e) -> {
            lblReloj.setText(DateFormat.getDateTimeInstance().format(new Date()));
        });

        reloj.setRepeats(true);
        reloj.setCoalesce(true);
        reloj.setInitialDelay(7);
        reloj.start();
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        lblReloj = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblPlanilla = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        btnCerrarSesion = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        lblSesion = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        btnCobrar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        lblImporteAbonar = new javax.swing.JLabel();
        cbxTipoFactura = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Caja registradora Straton");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("<- Caja Registradora ->");
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        lblReloj.setText("17:00 01/01/2021");

        jLabel3.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        jLabel3.setText("Operador de caja:");

        tblPlanilla.setAutoCreateRowSorter(true);
        tblPlanilla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Código", "Cantidad", "Detalle", "Precio U. $"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class, java.lang.Float.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tblPlanilla.setCellSelectionEnabled(true);
        tblPlanilla.setRowHeight(20);
        tblPlanilla.setSelectionBackground(java.awt.Color.green);
        jScrollPane1.setViewportView(tblPlanilla);
        if (tblPlanilla.getColumnModel().getColumnCount() > 0) {
            tblPlanilla.getColumnModel().getColumn(0).setHeaderValue("Código");
            tblPlanilla.getColumnModel().getColumn(1).setHeaderValue("Cantidad");
            tblPlanilla.getColumnModel().getColumn(2).setHeaderValue("Detalle");
            tblPlanilla.getColumnModel().getColumn(3).setHeaderValue("Precio U. $");
        }

        jLabel4.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        jLabel4.setText("Total productos:");

        btnCerrarSesion.setText("Cerrar sesión");
        btnCerrarSesion.setToolTipText("Cierra la sesión de caja.");
        btnCerrarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrarSesionActionPerformed(evt);
            }
        });

        jLabel5.setText("0");
        jLabel5.setToolTipText("Cantidad de productos acumulados para la venta.");

        lblSesion.setText("operador");

        jLabel7.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        jLabel7.setText("Reloj:");

        jLabel8.setText("0.000,00");
        jLabel8.setToolTipText("Monto de dinero a cobrar.");

        jLabel9.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        jLabel9.setText("Total importe $:");

        btnCobrar.setText("<<  Cobrar  >>");
        btnCobrar.setToolTipText("Cobra la mercadería vendida.");
        btnCobrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCobrarActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        jLabel2.setText("Importe abonar $:");

        jLabel10.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        jLabel10.setText("Importe vuelto $:");

        jLabel11.setText("0.000,00");
        jLabel11.setToolTipText("Monto de dinero a entregar.");

        lblImporteAbonar.setText("0.000,00");

        cbxTipoFactura.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "<Elija tipo de factura a emitir>", "Consumidor final", "Tipo A", "Tipo B" }));
        cbxTipoFactura.setToolTipText("Elija el tipo de factura a emitir.");

        jLabel6.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        jLabel6.setText("Emisión de factura:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 422, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblSesion)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnCerrarSesion))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnCobrar))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel8))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel11))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblImporteAbonar)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cbxTipoFactura, 0, 1, Short.MAX_VALUE))
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblReloj)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblReloj)
                        .addComponent(jLabel7)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(btnCerrarSesion)
                    .addComponent(lblSesion))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(cbxTipoFactura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(3, 3, 3)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(btnCobrar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(lblImporteAbonar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11))
                .addContainerGap(7, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Responde a la pulsación del botón Cerrar Sesión
    private void btnCerrarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarSesionActionPerformed
        int status = JOptionPane.showConfirmDialog(this, "¿Cierro sesión?", "Caja", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE);
        
        if(status == JOptionPane.YES_OPTION)
            dispose();  // La aplicación quiere salir...
    }//GEN-LAST:event_btnCerrarSesionActionPerformed

    // Responde a la llamada Cerrar Sesión
    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
        formWindowClosing(evt);
    }//GEN-LAST:event_formWindowClosed

    // Responde a la pulsación del botón Cerrar (x) del formulario
    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        codigo_salida = 0;
        reloj.stop();
        
        System.out.println("<< Sesión cerrada: " + lblReloj.getText() + " >>");
        CajaRegistradoraStraton.miInstancia().eliminarCandado();

        // Retorna al proceso padre <---> S.O.
        System.exit(codigo_salida);        
    }//GEN-LAST:event_formWindowClosing

    private void btnCobrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCobrarActionPerformed
        String importe = "-1,00";
        
        importe = JOptionPane.showInputDialog(this, "Importe $:", "Ingrese el importe a abonar", JOptionPane.INFORMATION_MESSAGE);
        if(importe == null)
            importe = "0,00";  // Respuesta al botón Cancelar
        else
            if(importe.isEmpty())
                importe = "0,00";  // Respuesta por importe no ingresado
        
        lblImporteAbonar.setText(importe);
        
        JOptionPane.showMessageDialog(this, "Total a cobrar $:", "Caja", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_btnCobrarActionPerformed

    /**
     * Punto de entrada al módulo CajaPantalla del paquete CajaRegistradoraStraton.
     * @param args the command line arguments
     */
    public static void arranque(String args) 
    {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CajaPantalla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CajaPantalla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CajaPantalla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CajaPantalla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new CajaPantalla(args).setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCerrarSesion;
    private javax.swing.JButton btnCobrar;
    private javax.swing.JComboBox<String> cbxTipoFactura;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblImporteAbonar;
    private javax.swing.JLabel lblReloj;
    private javax.swing.JLabel lblSesion;
    private javax.swing.JTable tblPlanilla;
    // End of variables declaration//GEN-END:variables
}
