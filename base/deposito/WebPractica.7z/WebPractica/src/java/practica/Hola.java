/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// Ejercicio WebPractica para Apache NetBeans IDE.
// Modificado por Eugenio Martínez -- Octubre de 2021.
// Está basado en el fichero ejemplo proporcionado por Apache Tomcat.
// c:\Bitnami\tomcatstack-9.0.20-0\apache-tomcat\webapps\docs\appdev\sample\src\mypackage\Hello.java
// Para que funcione correctamente este proyecto, es importante contar en Windows
// de Apache Tomcat, ver. 9.0.20 o superior y Java JDK 1.8
// La plataforma de desarrollo utilizada es de 64 bits.
// Sugerencia para instalar: Bitnami Tomcat Stack v9.0.20 para Windows 64 bits.
// Puede instalar a Tomcat de manera independiente en Windows, por favor dirijirse a:
// https://tomcat.apache.org/
// y seleccione la versión que mejor se ajusta a su S.O.
// Instale el archivo WebPractica\dist\WebPractica.war en el directorio de Tomcat:
// c:\Bitnami\tomcatstack-9.0.20-0\apache-tomcat\webapps\
// Y espere un momento hasta que el servidor Tomcat descomprima su proyecto en el lugar seleccionado.
// Ejecución del proyecto en el navegador de HTML: escriba lo siguiente en la barra de direcciones
// http://127.0.0.1:8080/WebPractica/
// ------------------------------------------------------------------------
// Recuerde que para crear cualquier proyecto Web~Java debe seleccionar la opción del menú principal de NetBeans:
// File\New Project\Java with Ant\Java Web\Web Application
// y preste atención a los diferentes mensajes que muestra el asistente de proyectos.

package practica;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Simple servlet to validate that the Hello, World example can
 * execute servlets.  In the web application deployment descriptor,
 * this servlet must be mapped to correspond to the link in the
 * "index.html" file.
 *
 * @author Craig R. McClanahan <Craig.McClanahan@eng.sun.com>
 */

public final class Hola extends HttpServlet {

    private static final long serialVersionUID = 1L;

    /**
     * Respond to a GET request for the content produced by
     * this servlet.
     *
     * @param request The servlet request we are processing
     * @param response The servlet response we are producing
     *
     * @exception IOException if an input/output error occurs
     * @exception ServletException if a servlet error occurs
     */
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException 
    {
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");
        
        try (PrintWriter writer = response.getWriter()) 
        {

            writer.println("<!DOCTYPE html><html>");
            writer.println("<head>");
            writer.println("<meta charset=\"UTF-8\" />");
            writer.println("<title>Ejemplo de ASP</title>");
            writer.println("</head>");
            writer.println("<body>");


            writer.println("<div style=\"float: left; padding: 10px;\">");
            writer.println("<img src=\"images/tomcat.gif\" alt=\"\" />");
            writer.println("</div>");
            writer.println("<h1>Ejemplo de aplicación servlet</h1>");
            writer.println("<p>");
            writer.println("Esto es la salida del servlet que es parte de la");
            writer.println("aplicación Hola Mundo.");
            writer.println("</p>");

            writer.println("</body>");
            writer.println("</html>");
        }
    }
}
