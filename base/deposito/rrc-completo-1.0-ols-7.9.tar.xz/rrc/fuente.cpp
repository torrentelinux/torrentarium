/*
    rrc
    Octulio Biletán - Julio de 2026.
    Rapid Response Command.
    Aplicación multiplataforma, para la gestión local/remota de equipos informáticos.
*/

#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <cstdlib>
#include <cstring>
#include <sys/stat.h>
#include <fcntl.h>

#ifdef _WIN32
#	include <windows.h>
#	include <direct.h>
#	include <io.h>

#	define ACCESS _access
#	define MKDIR(path) _mkdir(path)
#else
#	include <unistd.h>
#	include <sys/wait.h>
#	include <errno.h>
#	include <readline/readline.h>
#	include <readline/history.h>

#	define ACCESS access
#	define MKDIR(path) mkdir(path, 0755)
#endif

using namespace std;

// --- Utilidades ---
vector<string> split(const string &line)
{
    istringstream iss(line);
    vector<string> tokens;
    string token;

    while (iss >> token)
      tokens.push_back(token);

    return tokens;
}

bool existeDirectorio(const std::string &path) {
    struct stat info;
    return (stat(path.c_str(), &info) == 0 && S_ISDIR(info.st_mode));
}

bool crearDirectorio(const std::string &path) {
    if (MKDIR(path.c_str()) == 0) return true;
    if (errno == EEXIST) return true;
    perror(("Error al crear directorio: " + path).c_str());
    return false;
}

bool crearOActualizarQS(const std::string &binDir) {
#ifdef _WIN32
    std::string qsPath = binDir + "\\qs.bat";
    FILE *f = fopen(qsPath.c_str(), "w");
    if (!f) {
        perror(("Error al crear archivo: " + qsPath).c_str());
        return false;
    }
    fprintf(f, "@echo off\n");
    fprintf(f, "echo yo soy %%USERNAME%%\n");
    fclose(f);
#else
    std::string qsPath = binDir + "/qs";
    int fd = open(qsPath.c_str(), O_WRONLY | O_CREAT | O_TRUNC, 0755);
    if (fd < 0) {
        perror(("Error al crear archivo: " + qsPath).c_str());
        return false;
    }
    const char* contenido =
        "#!/bin/bash\n"
        "echo \"yo soy $(whoami)\"\n";
    if (write(fd, contenido, strlen(contenido)) < 0) {
        perror("Error al escribir en qs");
        close(fd);
        return false;
    }
    close(fd);
#endif
    return true;
}

void limpiarPantalla()
{
#ifdef _WIN32
    system("cls");
#else
    cout << "\033[2J\033[H" << flush;
#endif
}

void mostrarAyuda(void)
{
    cout << "Ayuda" << endl;
    cout << "Comandos admitidos en rrc:" << endl;
    cout << "· borrarPantalla = bp : borra toda la pantalla de textos." << endl;
    cout << "· ejecutarPrograma = ep : ejecuta un programa externo, se admiten sus argumentos." << endl;
    cout << "· ayuda = ? : muestra esta ayuda." << endl;
    cout << "· fin = f : finaliza la ejecución y regresa al proceso padre." << endl;

    cout << endl << "Combinación de teclas" << endl;
    cout << "Ctrl + c : interrumpe la ejecución del programa y regresa al proceso padre." << endl;
    cout << "Ctrl + d : finaliza la ejecución del programa y regresa al proceso padre." << endl;
    cout << "Ctrl + l : borra toda la pantalla de textos." << endl;
    cout << "Ctrl + m : avance de línea, mismo efecto que presionar la tecla 'Intro'." << endl;
    cout << "Teclas de movimiento/dirección : permiten la edición de la línea de comandos; arriba, abajo, izquierda y derecha." << endl;
}

void ejecutarComando(const vector<string> &args)
{
    if (args.empty()) 
    {
        cerr << "Error: No se especificó comando." << endl;
        return;
    }
#ifdef _WIN32
    string cmd;
    for (const auto &a : args) cmd += a + " ";
    system(cmd.c_str());
#else
    vector<char*> argv;
    for (const auto &arg : args) argv.push_back(const_cast<char*>(arg.c_str()));
    argv.push_back(nullptr);

    pid_t pid = fork();
    if(pid < 0)
    {
        perror("Error al crear proceso");
        return;
    }

    if(pid == 0)
    {
        execvp(argv[0], argv.data());
        perror("Error al ejecutar comando");
        exit(EXIT_FAILURE);
    }
    else
    {
        int status;
        waitpid(pid, &status, 0);
    }
#endif
}

std::string obtenerHome() {
#ifdef _WIN32
    const char* homeEnv = getenv("USERPROFILE");
    return (homeEnv && *homeEnv) ? homeEnv : "C:\\";
#else
    const char* homeEnv = getenv("HOME");
    return (homeEnv && *homeEnv) ? homeEnv : "/root";
#endif
}

std::string obtenerBinDir(const std::string &homeDir) {
#ifdef _WIN32
    return homeDir + "\\bin";
#else
    return homeDir + "/bin";
#endif
}

void prepararEntorno() {
    std::string homeDir = obtenerHome();
    std::string binDir = obtenerBinDir(homeDir);

    if (!existeDirectorio(binDir)) {
        if (crearDirectorio(binDir)) {
            std::cout << "[INFO] Directorio " << binDir << " creado.\n";
        }
    }

    if (crearOActualizarQS(binDir)) {
        cout << "[INFO] Comando 'qs' listo en " << binDir << "\n";
    }

#ifdef _WIN32
    string nuevoPath = binDir + ";" + getenv("PATH");
#else
    string nuevoPath = "/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:" + binDir;
#endif
    setenv("PATH", nuevoPath.c_str(), 1);
}

void inicializaConsola(void)
{
    // Cambiar/revisar antes la var. SHELL=
    system("setterm -reset&&setterm -initialize&&setterm -default");
    cout << "Consola inicializada." << endl;
}

// --- Programa principal ---
int main(int argc, char **argv, char **env)
{
	string linea;
	char *linea_entrada = (char *)NULL;

    inicializaConsola();

    cout << "=== rrc (Rapid Response Command) ===" << endl;
    cout << "Versión 1.0 -- Julio de 2026 -- edición Linux, 64 bits, castellano." << endl;
    cout << "Copyright (c)2026 Octulio Biletán. Todos los derechos reservados." << endl;
    cout << "Esto es software libre; Usted tiene la libertad de cambiarlo y redistribuirlo." << endl;
    cout << "No hay GARANTIA, a la extensión permitida por la ley." << endl;
    cout << endl;

    while(true)
    {
        linea_entrada = readline("» ");
        if(!linea_entrada)
	  break;

        linea = linea_entrada;

	if(*linea_entrada)
	  add_history(linea_entrada);

        auto tokens = split(linea);

        if(tokens.empty())
          continue;

        string comando = tokens[0];

        if(comando == "borrarPantalla" || comando == "bp")
        {
            limpiarPantalla();
        }
        else
        {
          if(comando == "ejecutarPrograma" || comando == "ep")
          {
            if(tokens.size() < 2)
            {
                cout << "Uso: ejecutarPrograma|ep <comando> [args...]" << endl;
                cout << "Ej.: ep ls -la" << endl;
                continue;
            }

            prepararEntorno();
            vector<string> cmdArgs(tokens.begin() + 1, tokens.end());
            ejecutarComando(cmdArgs);
          }
          else
          {
            if(comando == "ayuda" || comando == "?")
            {
		mostrarAyuda();
            }
            else
            {
              if(comando == "fin" || comando == "f")
              {
                cout << "Saliendo de rrc..." << endl;
                break;
              }
              else
              {
                cout << "Comando no reconocido: " << comando << endl;
                cout << "Ingrese comando '?' para solicitar una ayuda sobre esta aplicación." << endl;
              }
            }
          }
        }  // fin if()

        free(linea_entrada);
    }  // fin while()

    cout << endl;

    return 0;  // regresa al proceso padre.
}
