//---------------------------------------------------------------------------
// Encabezamiento : OpenProgramDialog.h
// Autor    : Eugenio Mart�nez - torrentelinux@gmail.com - Mayo de 2016
// Prop�sito: Ejecutar una aplicaci�n, documento, URL, etc.,
//            seleccionada por el usuario mediante un cuadro de di�logo simple.
//---------------------------------------------------------------------------

#ifndef OpenProgramDialogH
#define OpenProgramDialogH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Dialogs.hpp>
#include <Vcl.Graphics.hpp>
#include <Vcl.Buttons.hpp>
#include <VCLTee.TeCanvas.hpp>
#include <Vcl.Grids.hpp>
#include <Vcl.Outline.hpp>
#include <Vcl.Samples.DirOutln.hpp>
#include <Vcl.FileCtrl.hpp>
#include <Vcl.Imaging.pngimage.hpp>

#include "OpenProgramClass.h"
#include "OpenProgramDefs.h"

//---------------------------------------------------------------------------
class TfrmOpenProgram : public TForm
{
__published:	// IDE-managed Components
	TBevel *bvlBevel;
	TButton *OKBtn;
	TButton *CancelBtn;
	TButton *btnSelDir;
	TButton *btnBrowse;
	TBitBtn *btnDown;
	TBitBtn *btnUp;
	TComboBox *cbxOpen;
	TComboBox *cbxParameters;
	TComboBox *cbxDirectory;
	TComboBox *cftRun;
	TComboBox *cftOperation;
	TComboBox *cbxDelayTime;
	TComboBox *cbxPriority;
	TComboBox *cbxAffinity;
	TCheckBox *chkboxActivateDTime;
	TStaticText *txtOpen;
	TStaticText *txtText2;
	TStaticText *txtText3;
	TStaticText *txtParameters;
	TStaticText *txtDirectory;
	TStaticText *txtRun;
	TStaticText *txtErrorMsg;
	TStaticText *txtOperation;
	TStaticText *txtTrick;
	TStaticText *txtPriority;
	TStaticText *txtAffinity;
	TStaticText *txtDelayTime;
	TShape *shpCircle;
	TOpenDialog *dlgFileOpen;
	TImage *imgEscudo;
	TImage *imgMinimize;
	TImage *imgHelp;
	TImage *imgViewLog;
	void __fastcall CancelBtnClick(TObject *Sender);
	void __fastcall OKBtnClick(TObject *Sender);
	void __fastcall cbxOpenChange(TObject *Sender);
	void __fastcall FormActivate(TObject *Sender);
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall FormDestroy(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall btnBrowseClick(TObject *Sender);
	void __fastcall btnDownClick(TObject *Sender);
	void __fastcall btnUpClick(TObject *Sender);
	void __fastcall btnSelDirClick(TObject *Sender);
	void __fastcall btnDownMouseEnter(TObject *Sender);
	void __fastcall btnUpMouseEnter(TObject *Sender);
	void __fastcall txtTrickClick(TObject *Sender);
	void __fastcall txtTrickMouseEnter(TObject *Sender);
	void __fastcall imgMinimizeClick(TObject *Sender);
	void __fastcall imgHelpClick(TObject *Sender);
	void __fastcall imgMinimizeMouseEnter(TObject *Sender);
	void __fastcall imgHelpMouseEnter(TObject *Sender);
	void __fastcall imgViewLogClick(TObject *Sender);
	void __fastcall imgViewLogMouseEnter(TObject *Sender);
	void __fastcall chkboxActivateDTimeClick(TObject *Sender);
private:	// User declarations
protected:
	DirectoryDialog dlgDirOpen;
	File_Exec feInfo;

public:		// User declarations
	__fastcall TfrmOpenProgram(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmOpenProgram *frmOpenProgram;
//---------------------------------------------------------------------------
#endif
