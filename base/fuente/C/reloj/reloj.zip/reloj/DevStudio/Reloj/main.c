/* Versión de 'reloj' para Oracle Linux Server */
/* Entorno de desarrollo Oracle Developer Studio IDE ver. 12.6 */
/* 
 * File:   main.c
 * Author: Octulio Biletán
 *
 * Created on 19 de julio de 2024, 19:15
 */

#include <stdio.h>

int reloj(int argc, char **argv);

/*
 * Punto de entrada
 */
int main(int argc, char** argv) 
{
    /* Invoca a la func. reloj */
    return reloj(argc, argv);
}
